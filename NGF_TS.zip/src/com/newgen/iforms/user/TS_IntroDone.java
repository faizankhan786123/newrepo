package com.newgen.iforms.user;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.text.SimpleDateFormat;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.omni.jts.cmgr.XMLParser;

public class TS_IntroDone extends TS_Common
{
	public String onIntroduceDone(IFormReference iform, String controlName,String event, String data)
	{
		String strReturn="";
		TS.mLogger.debug("This is TS_IntroDone_Event");
		if("InsertIntoHistory".equals(controlName))
		{
			try 
			{
				JSONArray jsonArray=new JSONArray();
				JSONObject obj=new JSONObject();
				Calendar cal = Calendar.getInstance();		   
			    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			    String strDate = sdf.format(cal.getTime());
			    
				obj.put("Date & Time",strDate);
				obj.put("Workstep",iform.getActivityName());
				obj.put("User Name", iform.getUserName());
				//obj.put("Decision",iform.getValue("Decision"));
				//obj.put("Remarks", iform.getValue("REMARKS"));
				
			
				TS.mLogger.debug("Decision" +iform.getValue("Decision"));
				
				if("Initiation".equalsIgnoreCase(iform.getActivityName()))
				{
					obj.put("Entry Date Time",iform.getValue("CreatedDateTime"));
					obj.put("Decision","Introduce");
					obj.put("Remarks", "WI Introduced");
				}
					
				else
				{
					obj.put("Entry Date Time",iform.getValue("EntryDateTime"));
					obj.put("Decision",iform.getValue("Decision"));
					obj.put("Remarks", iform.getValue("REMARKS"));
				}
					
				
				TS.mLogger.debug("Entry Date Time : "+obj.get("Entry Date Time"));
				jsonArray.add(obj);
				iform.addDataToGrid("Q_NG_TS_WIHISTORY", jsonArray);
				
				TS.mLogger.debug("jsonArray : "+jsonArray);
				
				TS.mLogger.debug("WINAME: "+getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+", ControlName: "+controlName+", WI Histroy Added Successfully!");
				
				if("Card_Main_Check".equalsIgnoreCase(iform.getActivityName()))
				{
					ArrayList<String> typeOfReversal=new ArrayList<String>();
					typeOfReversal=(ArrayList) iform.getValue("Q_NG_TS_CSC_REVERSAL_DTLS");
					TS.mLogger.debug("Array : "+typeOfReversal);
					if(typeOfReversal.contains("Premium") && (typeOfReversal.size()==1))
					{
						iform.setValue("CSC_REVERSAL_TYPE","Y");
						TS.mLogger.debug("CSC_REVERSAL_TYPE : Y");
					}
					else if((typeOfReversal.size()>0))
					{
						iform.setValue("CSC_REVERSAL_TYPE","N");
						TS.mLogger.debug("CSC_REVERSAL_TYPE : N");
					}
					else
					{
						iform.setValue("CSC_REVERSAL_TYPE","Y");
						TS.mLogger.debug("CSC_REVERSAL_TYPE : Y");
					}
				}
			} 
			catch (Exception e) {
				TS.mLogger.debug("Exception in inserting WI History!" + e.getMessage());
			}
		}
		if("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS1".equals(controlName))
		{
			List ref_no=iform.getDataFromDB("select next value for CARD_DISPUTE_REF_NO As REF_NO");
			TS.mLogger.debug("Generated Ref No:"+ref_no);
			String value="";
			for(int i=0;i<ref_no.size();i++)
			{
				List<String> arr1=(List)ref_no.get(i);
				value=arr1.get(0);
			}
			iform.setTableCellValue("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS1",(Integer.parseInt(data)-1),0,value);
			//iform.setTableCellValue("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS1",(Integer.parseInt(data)-1),1,getCurrentDate("dd-MM-yyyy"));
			
		}
		if("InsertMailTrigger".equals(controlName))
		{
			try 
			{
				strReturn=new TSMailTrigger().MailTriggering(iform,controlName,event,data);
			}
			catch (Exception e) {
				TS.mLogger.debug("Exception in inserting Mail!" + e.getMessage());
			}
		}
		return strReturn;
	}
}