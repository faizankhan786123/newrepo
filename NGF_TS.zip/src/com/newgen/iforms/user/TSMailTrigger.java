package com.newgen.iforms.user;

import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import com.newgen.iforms.custom.IFormReference;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class TSMailTrigger extends TS_Common
{
	public static String MailTriggering(IFormReference iformObj,String controlId, String eventType,String paramInfo)
	{
		TS.mLogger.debug("Inside MailTriggering Method");
		String Mailquery=""; 
		String SMSquery="";
		String MailID=""; 
		String SMS_MOBNO="";
		int ProccessDefID=0;
		String TemplateType="";
		String Stage="";
		String Sub_Process_Name="";
		String service_name="";
		String sub_process_name="";
		String from_mailid="";
		String mail_subject="";
		String mail_template="";
		String sms_template="";
		String sms_placeholder="";
		String mail_placeholder="";
		String card_code="";
		String customer_name ="";
		String CustFirstName="";
		String SLA="";
		String tentative_date="";
		String RejectReason="";
		String OtherRejectReason="";
		String AMT_Dispute="";
		String transactionDate="";
		String cdAmt="";
		String cdAEDAmt="";
		String merchantName="";
		String cdDecision="";
		String cdReason="";
		String cdRefNo="";
		String TCCondition="";
		Double TotalAED=0.0;
		String CC_CD_MailId="";
		List slaList=iformObj.getDataFromDB("SELECT SLA FROM NG_TS_SERVICE_REQUEST_MASTER with(nolock) where ISACTIVE='Y'  and SERVICETYPE='"+iformObj.getValue("SERVICE_TYPE")+"'");
		TS.mLogger.debug("SLA List:"+slaList);
		for(int i=0;i<slaList.size();i++)
		{
			List<String> arr1=(List)slaList.get(i);
			SLA=arr1.get(0);
		}
		tentative_date=(String) iformObj.getValue("CREATED_AT");
		
		String paramArray[]=paramInfo.split("~");
		if(paramArray.length>0)
		{
			Sub_Process_Name=paramArray[0];
			Stage=paramArray[1];
		}
		else
		{
			TS.mLogger.debug("Data-"+paramInfo);
			return "false";
		}
		TS.mLogger.debug("Data-"+paramInfo);
		Date date = new Date();
		SimpleDateFormat DbformatDate = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		String strdate = DbformatDate.format(date);
		try 
		{				
			List ProcessDef = iformObj
				.getDataFromDB("select ProcessDefId from PROCESSDEFTABLE with(nolock) where ProcessName='TS'");				
			for(int i=0;i<ProcessDef.size();i++)
			{
				List<String> arr1=(List)ProcessDef.get(i);
				ProccessDefID= Integer.parseInt(arr1.get(0));
			}
		}
		catch (Exception e) 
		{
			TS.mLogger.debug(" WSNAME: "+iformObj.getActivityName()+", Exception in ProcessDef Query " + e.getMessage());
			return "false";
		}
		try 
		{				
		   String qry="select top 1 a.SERVICE_NAME,ISNULL(ISNULL(b.CSC_REQUEST_TYPE,b.RP_REQUEST_TYPE),'') as SUB_PROCESS,a.FROM_MAILID,"
		   		+ "a.MAIL_SUBJECT,a.MAIL_TEMPLATE,a.SMS_TEMPLATE,a.SMS_PLACEHOLDER,a.MAIL_PLACEHOLDER,"
		   		+ "ISNULL(COALESCE(RIGHT(b.HEADER_CARD_NO,4),RIGHT(b.HEADER_CIF,4)),'') as CARD_CODE,"
		   		+ "b.CUSTOMER_NAME,b.MOBILE_NO,b.EMAIL_ID,b.REJECT_REASON,b.OTHER_REJ_REASON,ISNULL(b.AD_AMT_DISPUTE,'') as AMT_IN_DISPUTE from NG_TS_TEMPLATE_MAPPING_MASTER a,NG_TS_EXTTABLE b WITH(NOLOCK) "
		   		+ "WHERE a.SERVICE_NAME=b.SERVICE_TYPE and a.STAGE='"+Stage+"' "
		   		+ "and a.SUB_PROCESS_NAME='"+Sub_Process_Name+"' "
		   		+ "and b.WI_NAME='"+getWorkitemName(iformObj)+"' and a.ISACTIVE='Y'";
		   List Templates = iformObj.getDataFromDB(qry);
		   for(int i=0;i<Templates.size();i++)
		   {
			   List<String> arr1=(List)Templates.get(i); 
			   service_name=arr1.get(0);
			   sub_process_name= arr1.get(1);
			   from_mailid=arr1.get(2);
			   mail_subject=arr1.get(3);
			   mail_template=arr1.get(4);
			   sms_template=arr1.get(5);
			   sms_placeholder=arr1.get(6);
			   mail_placeholder=arr1.get(7);
			   card_code=arr1.get(8);
			   customer_name=arr1.get(9);
			   SMS_MOBNO=arr1.get(10);
			   MailID=arr1.get(11);
			   RejectReason=arr1.get(12);
			   OtherRejectReason=arr1.get(13);
			   AMT_Dispute=arr1.get(14);
			   if(!"".equalsIgnoreCase(customer_name) && customer_name!=null)
			   {
				   CustFirstName=customer_name.split(" ")[0];
			   }
		    }
		   TS.mLogger.debug("qry:"+qry);
		   TS.mLogger.debug("qry:"+mail_template);
		   mail_template=mail_template.replaceAll("'", "''");
		   if("Card Dispute".equalsIgnoreCase(service_name))
		   { 
				if("TCProvided".equalsIgnoreCase(Stage) || "TC Update done".equalsIgnoreCase(Stage) )
				{
					TCCondition="and DECISION='Approve' and TEMP_CC_ASSIGN='Y'" ;
				}
				else if("TCNotProvided".equalsIgnoreCase(Stage))
				{
					TCCondition="and DECISION='Approve' and TEMP_CC_ASSIGN='N'" ;
				}
				else if("Dispute Accepted".equalsIgnoreCase(Stage) && ("TC".equalsIgnoreCase((String)iformObj.getValue("CD_ROUTED_FROM")) || "FC".equalsIgnoreCase((String)iformObj.getValue("CD_ROUTED_FROM"))))
				{
					TCCondition=" and DECISION='Approve' and MODIFIED_AT='"+iformObj.getValue("CD_ROUTED_FROM")+"'" ;
				}
				else if("Dispute Rejected".equalsIgnoreCase(Stage) && ("TC".equalsIgnoreCase((String)iformObj.getValue("CD_ROUTED_FROM")) || "FC".equalsIgnoreCase((String)iformObj.getValue("CD_ROUTED_FROM"))))
				{
					TCCondition="and DECISION='Decline' and MODIFIED_AT='"+iformObj.getValue("CD_ROUTED_FROM")+"'" ;
				}
				else if("Dispute Accepted".equalsIgnoreCase(Stage))
				{
					TCCondition=" and DECISION='Approve'" ;
				}
				else if("Dispute Rejected".equalsIgnoreCase(Stage))
				{
					TCCondition=" and DECISION='Decline'" ;
				}
			   String cdQry="SELECT TRANS_DATE,AMT_IN_FC,AMT_IN_AED,MERCHANT_NAME,ISNULL(DECISION,'') AS DECISION "
				   		+ ",ISNULL(ISNULL(OTH_DECLINE_REASON,DECLINE_REASON),'') AS DECLINE_REASON,REF_NO"
				   		+ " FROM NG_TS_TRANS_DISPUTE_GRID_DTLS WIH(nolock) WHERE WI_NAME='"+getWorkitemName(iformObj)+"'"+TCCondition;
			   TS.mLogger.debug("qry:"+cdQry);
			   List cdTransGrid = iformObj.getDataFromDB(cdQry);
			   if(cdTransGrid.size()==0)
			   {
				   return "true";
			   }
			   
			   TotalAED=0.0;
				   for(int i=0;i<cdTransGrid.size();i++)
				   {
					   List<String> arr1=(List)cdTransGrid.get(i); 
					   if("".equalsIgnoreCase(transactionDate))
					   {
						   transactionDate=dateTimeToDateFn(arr1.get(0));
					   }
					   else
					   {
						   transactionDate+=","+dateTimeToDateFn(arr1.get(0));
					   }
					   if("".equalsIgnoreCase(cdAmt))
					   {
						   cdAmt=arr1.get(1); 
					   }
					   else
					   {
						   cdAmt+=","+arr1.get(1);
					   }
					   if("".equalsIgnoreCase(cdAEDAmt))
					   {
						   cdAEDAmt=arr1.get(2); 
					   }
					   else
					   {
						   cdAEDAmt+=","+arr1.get(2);
					   }
					   if("".equalsIgnoreCase(merchantName))
					   {
						   merchantName=arr1.get(3); 
					   }
					   else
					   {
						   merchantName+=","+arr1.get(3);
					   }
					   if("".equalsIgnoreCase(cdDecision))
					   {
						   cdDecision=arr1.get(4); 
					   }
					   else
					   {
						   cdDecision+=","+arr1.get(4);
					   }  
					   if("".equalsIgnoreCase(cdReason))
					   {
						   cdReason=arr1.get(5); 
					   }
					   else
					   {
						   if(!"".equalsIgnoreCase(arr1.get(5)))
						   {
							   cdReason+=","+arr1.get(5);
						   } 
					   } 
					   if("".equalsIgnoreCase(cdRefNo))
					   {
						   cdRefNo=arr1.get(6); 
					   }
					   else
					   {
						   cdRefNo+=","+arr1.get(6);
					   }
					   if(!"".equalsIgnoreCase(arr1.get(2)))
					   {
						   TotalAED=TotalAED+Double.parseDouble(((arr1.get(2).replace(",",""))));
					   }   
					  
				    }
				   CC_CD_MailId="CardDisputes@rakbank.ae";
			   
		   	}
			String pHArr[]=mail_placeholder.split(",");
			for(String s:pHArr)
			{
				TS.mLogger.debug("PlaceHolderName: "+s);
				switch(s)
				{
					case "$WI_NAME$":
					{
						mail_template = mail_template.replace(s,getWorkitemName(iformObj));
						sms_template=sms_template.replace(s,getWorkitemName(iformObj));
						mail_subject=mail_subject.replace(s,getWorkitemName(iformObj));
						break;
					}
					case "$CARD_CODE$":
					{
						mail_template = mail_template.replace(s, card_code);
						sms_template=sms_template.replace(s,card_code);
						break;
					}
					case "$SUB_PROCESS_NAME$":
					{
						mail_template = mail_template.replace(s,sub_process_name);
						sms_template=sms_template.replace(s,sub_process_name);
						break;
					}
					case "$CUSTOMER_NAME$":
					{
						mail_template = mail_template.replace(s, CustFirstName);
						sms_template=sms_template.replace(s,CustFirstName);
						break;
					}
					case "$SLA_TAT$":
					{
						mail_template = mail_template.replace(s,SLA);
						sms_template=sms_template.replace(s,SLA);
						break;
					}
					case "$Approved_Dispute_Amount$":
					{
						mail_template = mail_template.replace(s,AMT_Dispute);
						//sms_template=sms_template.replace(s,"--");
						break;
					}
					case "$UPDATE_DATE$":
					{
						tentative_date=getSLADate(tentative_date, Integer.parseInt(SLA));
						mail_template = mail_template.replace(s,tentative_date);
						sms_template=sms_template.replace(s,tentative_date);
						break;
					}
					case "$REJECT_REASON$":
					{
						if("Others".equalsIgnoreCase(RejectReason))
						{
							RejectReason=OtherRejectReason;
						}
						mail_template = mail_template.replace(s,RejectReason);
						break;
					}
					case "$TRANSACTION_DATE$":
					{
						mail_template = mail_template.replace(s,transactionDate);
						break;
					}
					case "$AMOUNT$":
					{
						mail_template = mail_template.replace(s,cdAmt);
						break;
					}
					case "$AMOUNT_AED$":
					{
						mail_template = mail_template.replace(s,cdAEDAmt);
						break;
					}
					case "$MERCHANT_NAME$":
					{
						mail_template = mail_template.replace(s,merchantName);
						break;
					}
					case "$STATUS_OF_REQUEST$":
					{
						mail_template = mail_template.replace(s,cdDecision);
						break;
					}
					case "$Reason$":
					{
						mail_template = mail_template.replace(s,cdReason);
						break;
					}
					case "$DISPUTE_REF_NO$":
					{
						mail_template = mail_template.replace(s,cdRefNo);
						break;
					}
					case "$TOTAL_AED$":
					{
						sms_template = sms_template.replace(s,Double.toString(TotalAED));
						break;
					}
				}
				
			}
		   TS.mLogger.debug("Email:"+mail_template);
		   TS.mLogger.debug("SMS:"+sms_template);
			try
			{
				if(!"".equalsIgnoreCase(MailID) && !"".equalsIgnoreCase(mail_template) )
				{
					if(iformObj.getCabinetName().equalsIgnoreCase("rakcas")){
						MailID="testuser10@rakbanktst.ae";
					}
					//Comment in prod env.
					Mailquery="INSERT INTO WFMAILQUEUETABLE(mailFrom,mailTo,mailCC,mailBCC,mailSubject,mailMessage,mailContentType,attachmentISINDEX,attachmentNames,attachmentExts,mailPriority,mailStatus,statusComments,lockedBy,successTime,LastLockTime,insertedBy,mailActionType,insertedTime,processDefId,processInstanceId,workitemId,activityId,noOfTrials,zipFlag,zipName,maxZipSize,alternateMessage)values ('"+from_mailid+"','"+MailID+"','"+CC_CD_MailId+"',NULL,'"+mail_subject+"',N'"+mail_template+"','text/html;charset=UTF-8',NULL,NULL,NULL,1,'N',NULL,NULL,NULL,NULL,'CUSTOM','TRIGGER',getDate(),"+ProccessDefID+",'"+getWorkitemName(iformObj)+"',1,1,1,NULL,NULL,NULL,NULL)";
					int saveDataInDB = iformObj.saveDataInDB(Mailquery);
					TS.mLogger.debug("MailQuery:"+Mailquery+saveDataInDB);
				}
				
				if(!"".equalsIgnoreCase(SMS_MOBNO) && !"".equalsIgnoreCase(sms_template))
				{
					SMSquery="Insert into NG_RLOS_SMSQUEUETABLE (Alert_Name,Alert_Code,ALert_Status,Mobile_No,Alert_Text,WI_Name,Workstep_Name,inserted_Date_time) values ('TS SMS','TS','P','"+SMS_MOBNO+"','"+sms_template+"', '"+getWorkitemName(iformObj)+"','"+iformObj.getActivityName()+"', getdate())";
					int saveDataInDB1 = iformObj.saveDataInDB(SMSquery);
					TS.mLogger.debug("Query:"+SMSquery+saveDataInDB1);	
				}
				
			}
			catch (Exception e) 
			{
				TS.mLogger.debug(" WSNAME: "+iformObj.getActivityName()+", Exception in Inserting Mail " + e.getMessage());
			}
			
			TS.mLogger.debug("Inserted in WFMAILQUEUEMAILTABLE:"+mail_template);
		}
		catch (Exception e) 
		{
			TS.mLogger.debug(" WSNAME: "+iformObj.getActivityName()+", Exception in Mail Trigger " + e.getMessage());
			return "false";
		}
		
	
		return "true";
	}
	public static String dateTimeToDateFn(String dateTime)
	{
	   String date="";
       SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
       SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
       Date inputDateTime = new Date();
       try 
       {
    	   inputDateTime = sdf.parse(dateTime);
       } 
		catch (ParseException e) 
		{
			e.printStackTrace();
		}
       date=sdf1.format(inputDateTime);
       return date;
		
	}
	

}

