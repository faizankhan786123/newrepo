package com.newgen.iforms.user;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.mvcbeans.model.wfobjects.WDGeneralData;
import com.newgen.omni.jts.cmgr.XMLParser;
import com.sun.corba.se.pept.transport.Connection;

import java.beans.Statement;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringReader;
import java.net.Socket;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.activation.DataSource;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.json.simple.JSONArray;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.CharacterData;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
	
public class TS_Integration extends TS_Common 
{		
		LinkedHashMap<String,String> executeXMLMapMain = new LinkedHashMap<String,String>();
		public static String XMLLOG_HISTORY="NG_TS_XMLLOG_HISTORY";
		public XMLParser xmlobj;

	public String onclickevent(IFormReference iformObj,String control,String StringData) throws FileNotFoundException, IOException, ParserConfigurationException, SAXException 
	{
		String MQ_response="";
		String MQ_cardresponse="";
		String cardReturnCode = "";
		String cardReturnDesc = "";
		String inputXMLstate="";
		String outputXMLstate= "";
		String returnValue = "";
		String wiName=getWorkitemName(iformObj);
		String WSNAME=getActivityName(iformObj);
		String ReturnCode = "";
		String ReturnDesc = "";
		String MainCifId="";
		String MainCustomerName="";
		String msgToRtn = "";
		String Primaryemail = "";
		String primaryMobNum = "";
		String CARD_CRN_NO="";
		String primaryMobCode="";
		String eliteCust="";
		String CardNumber= "";
		String cardExpiryDate="";
		String generalStatus="";
		//CardNumber=(String)iformObj.getValue("HEADER_CARD_NO");
		if(StringData.trim().length()==16)
		{
			CardNumber=StringData.trim();
		}
		if(control.equalsIgnoreCase("CustomerSearch"))
		{
			MQ_response = MQ_connection_response(iformObj,control,StringData);	
			MQ_response=MQ_response.substring(MQ_response.indexOf("<?xml v"),MQ_response.indexOf("</MQ_RESPONSE_XML>"));
			if(MQ_response.indexOf("<ReturnCode>")!=-1)
			{
				ReturnCode = MQ_response.substring(MQ_response.indexOf("<ReturnCode>")+"</ReturnCode>".length()-1,MQ_response.indexOf("</ReturnCode>"));
				
			}
			if(MQ_response.indexOf("<ReturnDesc>")!=-1)
			{
				ReturnDesc = MQ_response.substring(MQ_response.indexOf("<ReturnDesc>")+"</ReturnDesc>".length()-1,MQ_response.indexOf("</ReturnDesc>"));
				
			}
			TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Return  code for the entity detail call"+ReturnCode);
			
			if(ReturnCode.equalsIgnoreCase("0000"))
			{
				if(!"".equalsIgnoreCase(CardNumber))
				{
					MQ_cardresponse=MQ_connection_response(iformObj,"CustomerSearchForcard",CardNumber);
					if(MQ_cardresponse.indexOf("<ReturnCode>")!=-1)
					{
						cardReturnCode = MQ_cardresponse.substring(MQ_cardresponse.indexOf("<ReturnCode>")+"</ReturnCode>".length()-1,MQ_cardresponse.indexOf("</ReturnCode>"));
						
					}
					if(MQ_cardresponse.indexOf("<ReturnDesc>")!=-1)
					{
						cardReturnDesc = MQ_cardresponse.substring(MQ_cardresponse.indexOf("<ReturnDesc>")+"</ReturnDesc>".length()-1,MQ_cardresponse.indexOf("</ReturnDesc>"));
						
					}
					TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Return  code for the Card detail call"+cardReturnCode);

					if(cardReturnCode.equalsIgnoreCase("0000"))
					{
						if(MQ_cardresponse.contains("<CardStatus>"))
						{
							generalStatus = MQ_cardresponse.substring(MQ_cardresponse.indexOf("<CardStatus>")+"</CardStatus>".length()-1,MQ_cardresponse.indexOf("</CardStatus>"));
						}
						if(MQ_cardresponse.contains("<ExpiryDate>"))
						{
							cardExpiryDate = MQ_cardresponse.substring(MQ_cardresponse.indexOf("<ExpiryDate>")+"</ExpiryDate>".length()-1,MQ_cardresponse.indexOf("</ExpiryDate>"));
						}	
					}
					if(!"".equalsIgnoreCase(generalStatus) && null!=generalStatus)
					{
						iformObj.setValue("GENERAL_STATUS", generalStatus);
					}
					if(!"".equalsIgnoreCase(cardExpiryDate) && null!=cardExpiryDate)
					{
						iformObj.setValue("EXPIRY_DATE", cardExpiryDate);
					}
				}
				
				if(MQ_response.contains("<CIFID>"))
				{
					MainCifId = MQ_response.substring(MQ_response.indexOf("<CIFID>")+"</CIFID>".length()-1,MQ_response.indexOf("</CIFID>"));
				}
				if(MQ_response.contains("<ECRNumber>"))
				{
					CARD_CRN_NO = MQ_response.substring(MQ_response.indexOf("<ECRNumber>")+"</ECRNumber>".length()-1,MQ_response.indexOf("</ECRNumber>"));
				}
				if(MQ_response.contains("<FullName>"))
				{
					MainCustomerName = MQ_response.substring(MQ_response.indexOf("<FullName>")+"</FullName>".length()-1,MQ_response.indexOf("</FullName>"));
					
				}
				if(MQ_response.contains("<IsPremium>"))
				{
					eliteCust= MQ_response.substring(MQ_response.indexOf("<IsPremium>")+"</IsPremium>".length()-1,MQ_response.indexOf("</IsPremium>"));
					if("Y".equalsIgnoreCase(eliteCust))
					{
						eliteCust="Yes";
					}
					else
					{
						eliteCust="No";
					}
					
				}
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+MainCifId+MainCustomerName);
				
				if (MQ_response.contains("<EmailDet>"))
				{
					Document recordDoc3=MapXML.getDocument(MQ_response);
					NodeList records3= MapXML.getNodeListFromDocument(recordDoc3, "EmailDet");
					TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Total Lines returned for document tag: "+records3.getLength());
					if(records3.getLength() > 0)
					{
						for(int rec3=0;rec3<records3.getLength();rec3++)
						{
							if(MapXML.getTagValueFromNode(records3.item(rec3),"MailPrefFlag").equalsIgnoreCase("Y"))
							{
								Primaryemail = MapXML.getTagValueFromNode(records3.item(rec3),"EmailID");
								if(!"".equalsIgnoreCase(Primaryemail) && null!=Primaryemail)
								{
									iformObj.setValue("EMAIL_ID", Primaryemail);
								}		
							}
						}
					}
				}
				if (MQ_response.contains("<PhnDet>"))
				{
					Document recordDoc4=MapXML.getDocument(MQ_response);
					NodeList records4= MapXML.getNodeListFromDocument(recordDoc4, "PhnDet");
					TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Total Lines returned for document tag: "+records4.getLength());
					if(records4.getLength() > 0)
					{
						for(int rec4=0;rec4<records4.getLength();rec4++)
						{
							if(MapXML.getTagValueFromNode(records4.item(rec4),"PhnPrefFlag").equalsIgnoreCase("Y"))
							{
								//primaryMobNum = MapXML.getTagValueFromNode(records4.item(rec4),"PhoneNo");
								primaryMobCode = MapXML.getTagValueFromNode(records4.item(rec4),"PhnCountryCode");
								primaryMobCode=primaryMobCode.replaceAll("[+()0]", "");
								primaryMobNum = MapXML.getTagValueFromNode(records4.item(rec4),"PhnLocalCode");
								if(!"".equalsIgnoreCase(primaryMobNum) && null!=primaryMobNum && primaryMobCode!=null)
									primaryMobNum=primaryMobCode+primaryMobNum;
									iformObj.setValue("MOBILE_NO", primaryMobNum);
							}
						}
					}
				}
				
				if(!"".equalsIgnoreCase(MainCifId) && null!=MainCifId){
					iformObj.setValue("CIF_ID", MainCifId);
				}
				if(!"".equalsIgnoreCase(MainCustomerName) && null!=MainCustomerName){
					iformObj.setValue("CUSTOMER_NAME", MainCustomerName);
				}
				if(!"".equalsIgnoreCase(CARD_CRN_NO) && null!=CARD_CRN_NO){
					iformObj.setValue("CARD_CRN_NO", CARD_CRN_NO);
				}
				if(!"".equalsIgnoreCase(eliteCust) && null!=eliteCust){
					iformObj.setValue("ELITE_CUST_NO", eliteCust);
				}
				
				
				iformObj.setValue("IS_CUST_SEARCH_DONE", "Y");
				returnValue = "Integration call successfull";
			
			}
			else 
			{
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+"Other than 0000 code");
				iformObj.setValue("IS_CUST_SEARCH_DONE", "N");
				returnValue = "Integration call failed";
			}
			return returnValue;	
		
		 }
		else if(control.equalsIgnoreCase("RaiseSRO")) 
		{
			String processDefIdSRO ="";
			try 
			{
				List ProcessDef = iformObj.getDataFromDB("select ProcessDefId from PROCESSDEFTABLE with(nolock) where ProcessName='SRO'");				
				for(int i=0;i<ProcessDef.size();i++)
				{
					List<String> arr1=(List)ProcessDef.get(i);
					processDefIdSRO=arr1.get(0);
				}
			}
			catch (Exception e) 
			{
				TS.mLogger.debug(" WSNAME: "+iformObj.getActivityName()+", Exception in ProcessDef SRO Query " + e.getMessage());
				return "false";
			}
			String paramForSRO = StringData;
			TS.mLogger.info("paramForSRO : "+paramForSRO);
			String attributeTagSRO = ""; 
			String wfuploadInputXMLSRO = ""; 
			String wfuploadOutputXMLSRO = ""; 
			String WINumberSRO = "";
			attributeTagSRO = attributeTagSRO + "Service_Request_Type" + (char)21 +paramForSRO.split("~")[0]+(char)25;
			attributeTagSRO = attributeTagSRO + "Team" + (char)21 +paramForSRO.split("~")[1]+(char)25;
			attributeTagSRO = attributeTagSRO + "Remarks" + (char)21 +paramForSRO.split("~")[2]+(char)25;
			
			wfuploadInputXMLSRO = getWFUploadWorkItemXML(iformObj, processDefIdSRO, attributeTagSRO);
			TS.mLogger.info("wfuploadInputXMLSRO : "+wfuploadInputXMLSRO);
			wfuploadOutputXMLSRO = ExecuteQueryOnServer(wfuploadInputXMLSRO,iformObj);
			TS.mLogger.info("wfuploadOutputXMLSRO : "+wfuploadOutputXMLSRO);
			if(wfuploadOutputXMLSRO.indexOf("<MainCode>0</MainCode>")>-1)
			{
				TS.mLogger.info("WFUpload for SRO is successfull");
				xmlobj = new XMLParser(wfuploadOutputXMLSRO);
				WINumberSRO = xmlobj.getValueOf("ProcessInstanceId");
				TS.mLogger.info("WINumberSRO : "+WINumberSRO);
				iformObj.setValue("SRO_NO",WINumberSRO);
				iformObj.setValue("SRO_STATUS","WI Created");
				//iformObj.setValue("IS_SRO_RAISED","Y");
				isSRORaised(iformObj);
				returnValue = "WI Created";
			}
			else
			{
				TS.mLogger.info("WFUpload for SRB is failed");
				iformObj.setValue("SRO_STATUS","WI Created");
				returnValue = "WI Not Created";
			}	
		}
		 return returnValue;		 
       }

public String getImages(String tempImagePath,String debt_acc_num,String[] imageArr,String[] remarksArr, IFormReference iformObj)
{
	
	String strCode =null;
	StringBuilder html = new StringBuilder();
	if(imageArr==null)
		return "";
	for (int i=0;i<imageArr.length;i++)
	{
		try
		{	
			TS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Inside Get Images 0");
			//byte[] btDataFile = new sun.misc.BASE64Decoder().decodeBuffer(imageArr[i]);
			//File of = new File(filePath+debt_acc_num+"imageCreatedN"+i+".jpg");
			String imagePath = System.getProperty("user.dir")+ tempImagePath+System.getProperty("file.separator")+debt_acc_num+"imageCreatedN"+i+".jpg";
			TS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", imagePath"+imagePath);
			File of = new File(imagePath);
			
			FileOutputStream osf = new FileOutputStream(of);
			//osf.write(btDataFile);
			osf.flush();
			osf.close();
		}
		catch (Exception e)
		{
			TS.mLogger.debug( e.getMessage());
			e.printStackTrace();
			TS.mLogger.debug("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Not able to get the image imageCreated"+e);
		}
	}
	return "";
}
	public static String readFileFromServer(String filename)
	{	
		TS.mLogger.debug("inside readFileFromServer--"+filename);
		String xmlReturn="";
		try {
			File file = new File(filename);
			FileReader fileReader = new FileReader(file);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			StringBuffer stringBuffer = new StringBuffer();
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				stringBuffer.append(line);
				stringBuffer.append("\n");
			}
			fileReader.close();
			TS.mLogger.debug("Contents of file:");
			xmlReturn = stringBuffer.toString();
			TS.mLogger.debug("file content"+xmlReturn);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		return xmlReturn;
	
	
	}
	
	public static String writeFileFromServer(String filename,String oldString)
	{
		 String newString=oldString;	
		TS.mLogger.debug("\n Inside writeFileFromServer function");
		
		try {
			 //newString = oldString.replaceAll("<p>", " ");
			 //newString = newString.replaceAll("</p>"," ");
            //Rewriting the input text file with newString
			
            FileOutputStream out = new FileOutputStream(filename);
			out.write(newString.getBytes());
			out.close();
			
			//TS.mLogger.debug("after writing into file"+newString);
				
		} catch (IOException e) {
			TS.mLogger.debug("The Exception is "+e.getMessage());
			e.printStackTrace();
		}
			return newString;
	}

	
	public static String getCharacterDataFromElement(Element e) {
		Node child = e.getFirstChild();
		if (child instanceof CharacterData) {
		   CharacterData cd = (CharacterData) child;
		   return cd.getData();
		}
		return "NO_DATA";
	}
	
	public String MQ_connection_response(IFormReference iformObj,String control,String Data) 
	{

		TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Inside MQ_connection_response function");
		//final IFormReference iFormOBJECT;
		//final WDGeneralData wdgeneralObj;	
		Socket socket = null;
		OutputStream out = null;
		InputStream socketInputStream = null;
		DataOutputStream dout = null;
		DataInputStream din = null;
		String mqOutputResponse = null;
		String mqOutputResponse_Entity = null;
		String mqOutputResponse_Account = null;
		String mqInputRequest = null;
		String cabinetName = getCabinetName(iformObj);
		String wi_name = getWorkitemName(iformObj);
		String ws_name = getActivityName(iformObj);
		String sessionID = getSessionId(iformObj);
		String userName = getUserName(iformObj);
		String socketServerIP;
		int socketServerPort;
		//wdgeneralObj = iformObj.getObjGeneralData();
		//sessionID = wdgeneralObj.getM_strDMSSessionId();
		String CIFNumber="";
		String EmiratesID ="";
		String AccountNumber="";
		String CardNumber="";
		String LoanAgreementID="";
		String callName="";
		String[] paramArray;
		
		try
		{
			
			TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+",Inside MQ_connection_response function: control --"+control);
			TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+",Inside MQ_connection_response function: Data --"+Data); 
			
			if(control.equalsIgnoreCase("CustomerSearch"))
			{
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+",Inside MQ_connection_response function: if block"); 
				if(Data.length()==16)
				{
					CardNumber=Data;
					iformObj.setValue("HEADER_CARD_NO",CardNumber );
					
				}
				else
				{
					AccountNumber=Data;
					iformObj.setValue("HEADER_CIF",AccountNumber );
				}
				//AccountNumber=  (String)iformObj.getValue("HEADER_CIF");
				//CardNumber= (String)iformObj.getValue("HEADER_CARD_NO");
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", CIFNumber is --"+CIFNumber);
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", CardNumber is --"+CardNumber);
				callName="ENTITY_DETAILS";	 
				 String account_type="A";
				//getAccountType for Card
				 
				if (AccountNumber.equalsIgnoreCase("")) 
				{
					if (!CardNumber.equalsIgnoreCase("")) 
					{
						AccountNumber = CardNumber;
						account_type = "C";
	
					}
					//code change for Loan Agreement ID
					else if (!LoanAgreementID.equalsIgnoreCase("")) 
					{
						AccountNumber = LoanAgreementID;
						account_type = "L";
					} 
					else
					{
						account_type = "";
					}	
				}
				java.util.Date d1=new Date();
				SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.mmm");
				String DateExtra2=sdf1.format(d1)+"04:00";
				StringBuilder finalXml = new StringBuilder("<EE_EAI_MESSAGE>\n"+
							"<EE_EAI_HEADER>\n"+
							"<MsgFormat>ENTITY_DETAILS</MsgFormat>\n"+
							"<MsgVersion>0001</MsgVersion>\n"+
							"<RequestorChannelId>BPM</RequestorChannelId>\n"+
							"<RequestorUserId>BPMUSER</RequestorUserId>\n"+
							"<RequestorLanguage>E</RequestorLanguage>\n"+
							"<RequestorSecurityInfo>secure</RequestorSecurityInfo>\n"+
							"<ReturnCode>0000</ReturnCode>\n"+
							"<ReturnDesc>TS</ReturnDesc>\n"+
							"<MessageId>143282709427399867</MessageId>\n"+
							"<Extra1>REQ||RAK_TEMP_USER_3394.RAK_TEMP_USER_3394</Extra1>\n"+
							"<Extra2>"+DateExtra2+"</Extra2>\n"+
							"</EE_EAI_HEADER>\n"+
							"<CustomerDetails><BankId>RAK</BankId><CIFID>"+CIFNumber+"</CIFID><ACCType>"+account_type+"</ACCType><ACCNumber>"+AccountNumber+"</ACCNumber><EmiratesID>"+EmiratesID+"</EmiratesID><InquiryType>CustomerAndAccount</InquiryType><RelCIFDetFlag>Y</RelCIFDetFlag><FreeField1></FreeField1><FreeField2></FreeField2><FreeField3></FreeField3></CustomerDetails>\n"+
							"</EE_EAI_MESSAGE>");
				mqInputRequest = getMQInputXML(sessionID, cabinetName,wi_name, ws_name, userName, finalXml);
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", mqInputRequest for Entity Detail call" + mqInputRequest);
				
			}
			else if(control.equalsIgnoreCase("CustomerSearchForcard"))
			{
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+",Inside MQ_connection_response function: if block"); 
				CardNumber= (String)iformObj.getValue("HEADER_CARD_NO");
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", CardNumber is --"+CardNumber);
				java.util.Date d1=new Date();
				SimpleDateFormat sdf1=new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.mmm");
				String DateExtra2=sdf1.format(d1)+"04:00";
				callName="CARD_DETAILS";	
				StringBuilder finalXml=new StringBuilder("<EE_EAI_MESSAGE>\n"+
						"<EE_EAI_HEADER>\n"+
						"<MsgFormat>CARD_DETAILS</MsgFormat>\n"+
						"<MsgVersion>0001</MsgVersion>\n"+
						"<RequestorChannelId>BPM</RequestorChannelId>\n"+
						"<RequestorUserId>BPMUSER</RequestorUserId>\n"+
						"<RequestorLanguage>E</RequestorLanguage>\n"+
						"<RequestorSecurityInfo>secure</RequestorSecurityInfo>\n"+
						"<ReturnCode>0000</ReturnCode>\n"+
						"<ReturnDesc>saddd</ReturnDesc>\n"+
						"<MessageId>A2503006</MessageId>\n"+
						"<Extra1>REQ||BPM.123</Extra1>\n"+
						"<Extra2>"+DateExtra2+"</Extra2>\n"+
						"</EE_EAI_HEADER>\n"+
						"<CardDetails>\n"+
						"<BankId>RAK</BankId>\n"+
						"<CIFID></CIFID>\n"+
						"<CardCRNNumber></CardCRNNumber>\n"+
						"<CardNumber>"+Data+"</CardNumber>\n"+
						"<ResponseReqd>P</ResponseReqd></CardDetails>\n"+
						"</EE_EAI_MESSAGE>");
				mqInputRequest = getMQInputXML(sessionID, cabinetName,wi_name, ws_name, userName, finalXml);
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", mqInputRequest for Card Detail call" + mqInputRequest);	 
			
			}
		
			TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", userName "+ userName);
			TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", sessionID "+ sessionID);
			
			String sMQuery = "SELECT SocketServerIP,SocketServerPort FROM NG_BPM_MQ_TABLE with (nolock) where ProcessName = 'TS' and CallingSource = 'Form'";
			List<List<String>> outputMQXML = iformObj.getDataFromDB(sMQuery);
			if (!outputMQXML.isEmpty()) 
			{
				socketServerIP = outputMQXML.get(0).get(0);
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", socketServerIP " + socketServerIP);
				socketServerPort = Integer.parseInt(outputMQXML.get(0).get(1));
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", socketServerPort " + socketServerPort);
				if (!("".equalsIgnoreCase(socketServerIP) && socketServerIP == null && socketServerPort==0)) {
					socket = new Socket(socketServerIP, socketServerPort);
					//new Code added by Deepak to set connection timeout
					int connection_timeout=60;
						try
						{
							connection_timeout=70;
						}
						catch(Exception e){
							connection_timeout=60;
						}
						
					socket.setSoTimeout(connection_timeout*1000);
					out = socket.getOutputStream();
					socketInputStream = socket.getInputStream();
					dout = new DataOutputStream(out);
					din = new DataInputStream(socketInputStream);
					TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", dout " + dout);
					TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", din " + din);
					mqOutputResponse = "";
					
			
					if (mqInputRequest != null && mqInputRequest.length() > 0) {
						int outPut_len = mqInputRequest.getBytes("UTF-16LE").length;
						TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Final XML output len: "+outPut_len + "");
						mqInputRequest = outPut_len + "##8##;" + mqInputRequest;
						TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", MqInputRequest Input Request Bytes : "+ mqInputRequest.getBytes("UTF-16LE"));
						dout.write(mqInputRequest.getBytes("UTF-16LE"));dout.flush();
					}
					byte[] readBuffer = new byte[500];
					int num = din.read(readBuffer);
					if (num > 0) {
			
						byte[] arrayBytes = new byte[num];
						System.arraycopy(readBuffer, 0, arrayBytes, 0, num);
						mqOutputResponse = mqOutputResponse+ new String(arrayBytes, "UTF-16LE");
						TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", mqOutputResponse/message ID :  "+mqOutputResponse);
						if(!"".equalsIgnoreCase(mqOutputResponse) && control.equalsIgnoreCase("CustomerSearch"))
						{
							mqOutputResponse = getOutWtthMessageID(callName,iformObj,mqOutputResponse);
						}
						if(!"".equalsIgnoreCase(mqOutputResponse) && control.equalsIgnoreCase("CustomerSearchForcard"))
						{
							mqOutputResponse = getOutWtthMessageID(callName,iformObj,mqOutputResponse);
						}	
						if(mqOutputResponse.contains("&lt;")){
							mqOutputResponse=mqOutputResponse.replaceAll("&lt;", "<");
							mqOutputResponse=mqOutputResponse.replaceAll("&gt;", ">");
						}
					}
					socket.close();
					return mqOutputResponse;
					
				} else {
					TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", SocketServerIp and SocketServerPort is not maintained "+"");
					TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", SocketServerIp is not maintained "+	socketServerIP);
					TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", SocketServerPort is not maintained "+	socketServerPort);
					return "MQ details not maintained";
				}
			}
			else 
			{
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", SOcket details are not maintained in NG_BPM_MQ_TABLE table"+"");
				return "MQ details not maintained";
			}
		
		} 
		catch (Exception e) 
		{
			TS.printException(e);
			return "";
		}
		finally
		{
			try{
				if(out != null){
					
					out.close();
					out=null;
					}
				if(socketInputStream != null){
					
					socketInputStream.close();
					socketInputStream=null;
					}
				if(dout != null){
					
					dout.close();
					dout=null;
					}
				if(din != null){
					
					din.close();
					din=null;
					}
				if(socket != null){
					if(!socket.isClosed()){
						socket.close();
					}
					socket=null;
				}
			}catch(Exception e)
			{
				TS.mLogger.info("WINAME : "+getWorkitemName(iformObj)+", WSNAME: "+getActivityName(iformObj)+", Final Exception Occured Mq_connection_CC"+e.getStackTrace());
			}
		}
	}
	
	private static String getMQInputXML(String sessionID, String cabinetName,
			String wi_name, String ws_name, String userName,
			StringBuilder final_xml) {
			//FormContext.getCurrentInstance().getFormConfig();
			//TS.mLogger.debug("inside getMQInputXML function");
			StringBuffer strBuff = new StringBuffer();
			strBuff.append("<APMQPUTGET_Input>");
			strBuff.append("<SessionId>" + sessionID + "</SessionId>");
			strBuff.append("<EngineName>" + cabinetName + "</EngineName>");
			strBuff.append("<XMLHISTORY_TABLENAME>NG_TS_XMLLOG_HISTORY</XMLHISTORY_TABLENAME>");
			strBuff.append("<WI_NAME>" + wi_name + "</WI_NAME>");
			strBuff.append("<WS_NAME>" + ws_name + "</WS_NAME>");
			strBuff.append("<USER_NAME>" + userName + "</USER_NAME>");
			strBuff.append("<MQ_REQUEST_XML>");
			strBuff.append(final_xml);
			strBuff.append("</MQ_REQUEST_XML>");
			strBuff.append("</APMQPUTGET_Input>");
			//TS.mLogger.debug("inside getOutputXMLValues"+ "getMQInputXML"+ strBuff.toString());
			return strBuff.toString();
		}
		
	public String getOutWtthMessageID(String callName,IFormReference iformObj,String message_ID){
		String outputxml="";
		try{
			String wi_name = getWorkitemName(iformObj);
			String str_query = "select OUTPUT_XML from NG_TS_XMLLOG_HISTORY with (nolock) where CALLNAME ='"+callName+"' and MESSAGE_ID ='"+message_ID+"' and WI_NAME = '"+wi_name+"'";
			TS.mLogger.debug("inside getOutWtthMessageID str_query: "+ str_query);
			List<List<String>> result=iformObj.getDataFromDB(str_query);
			String Integration_timeOut="100";
			int Loop_wait_count=10;
			try
			{
				Loop_wait_count=Integer.parseInt(Integration_timeOut);
			}
			catch(Exception ex)
			{
				Loop_wait_count=10;
			}
		
			for(int Loop_count=0;Loop_count<Loop_wait_count;Loop_count++){
				if(result.size()>0){
					outputxml = result.get(0).get(0);
					break;
				}
				else{
					Thread.sleep(1000);
					result=iformObj.getDataFromDB(str_query);
				}
			}
			
			if("".equalsIgnoreCase(outputxml)){
				outputxml="Error";
			}
			TS.mLogger.debug("getOutWtthMessageID" + outputxml);				
		}
		catch(Exception e){
			TS.mLogger.debug("Exception occurred in getOutWtthMessageID" + e.getMessage());
			TS.mLogger.debug("Exception occurred in getOutWtthMessageID" + e.getStackTrace());
			outputxml="Error";
		}
		return outputxml;
	}
	
	public Document getDocument(String xml) throws ParserConfigurationException, SAXException, IOException
	{
		// Step 1: create a DocumentBuilderFactory
		DocumentBuilderFactory dbf =
				DocumentBuilderFactory.newInstance();

		// Step 2: create a DocumentBuilder
		DocumentBuilder db = dbf.newDocumentBuilder();

		// Step 3: parse the input file to get a Document object
		Document doc = db.parse(new InputSource(new StringReader(xml)));
		TS.mLogger.debug("xml is-"+xml);
		return doc;
	}
	
	public String maskXmlogBasedOnCallType(String outputxmlMasked, String callType)
	{
		String Tags = "";
		if (callType.equalsIgnoreCase("CUSTOMER_DETAILS"))
		{
			outputxmlMasked = outputxmlMasked.replace("("," ").replace(")"," ").replace("@"," ").replace("+"," ").replace("&amp;/"," ").replace("&amp; /"," ").replace("."," ").replace(","," ");
			Tags = "<ACCNumber>~,~<AccountName>~,~<ECRNumber>~,~<DOB>~,~<MothersName>~,~<IBANNumber>~,~<DocId>~,~<DocExpDt>~,~<DocIssDate>~,~<PassportNum>~,~<MotherMaidenName>~,~<LinkedDebitCardNumber>~,~<FirstName>~,~<MiddleName>~,~<LastName>~,~<FullName>~,~<ARMCode>~,~<ARMName>~,~<PhnCountryCode>~,~<PhnLocalCode>~,~<PhoneNo>~,~<EmailID>~,~<CustomerName>~,~<CustomerMobileNumber>~,~<PrimaryEmailId>~,~<Fax>~,~<AddressType>~,~<AddrLine1>~,~<AddrLine2>~,~<AddrLine3>~,~<AddrLine4>~,~<POBox>~,~<City>~,~<Country>~,~<AddressLine1>~,~<AddressLine2>~,~<AddressLine3>~,~<AddressLine4>~,~<CityCode>~,~<State>~,~<CountryCode>~,~<Nationality>~,~<ResidentCountry>~,~<PrimaryContactName>~,~<PrimaryContactNum>~,~<SecondaryContactName>~,~<SecondaryContactNum>";
			
		}
		if (!Tags.equalsIgnoreCase(""))
		{
	    	String Tag[] = Tags.split("~,~");
	    	for(int i=0;i<Tag.length;i++)
	    	{
	    		//outputxmlMasked = maskXmlTags(outputxmlMasked,Tag[i]);
	    	}
		}
    	return outputxmlMasked;
	}
	
}


