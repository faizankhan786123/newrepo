package com.newgen.iforms.user;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import javax.swing.JOptionPane;
import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.xmlapi.IFormXmlResponse;


public class TS_Click extends TS_Common {

	public String clickEvent(IFormReference iform, String controlName, String data) throws FileNotFoundException, IOException, ParserConfigurationException, SAXException
	{
		TS.mLogger.debug("WINAME : "+getWorkitemName(iform)+", WSNAME: "+getActivityName(iform)+", controlName "+controlName+", data "+data);
		// TODO Auto-generated method stub
	
	if(controlName.equalsIgnoreCase("RaiseSRO") || controlName.equalsIgnoreCase("CustomerSearch")) {
		return new TS_Integration().onclickevent(iform, controlName, data);	
	}
	
	else {
		return "";
	}
	    	
	}
	
}
