package com.newgen.iforms.user;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.io.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import com.newgen.iforms.custom.IFormReference;
import com.newgen.iforms.xmlapi.IFormXmlResponse;
import com.newgen.mvcbeans.model.wfobjects.WDGeneralData;
import com.newgen.wfdesktop.xmlapi.WFInputXml;

import ISPack.CPISDocumentTxn;
import ISPack.ISUtil.JPDBRecoverDocData;
import ISPack.ISUtil.JPISException;
import ISPack.ISUtil.JPISIsIndex;

//import com.newgen.iforms.user.*;
import com.newgen.omni.wf.util.app.NGEjbClient;

public class TS_Common 
{
	//Map<String,String> constantsHashMap=new HashMap<>();

	String 	sLocaleForMessage = java.util.Locale.getDefault().toString();

	public static String maskXmlTags(List<List<String>> outputMQXML,String Tag)
    {
        Pattern p = Pattern.compile("(?<="+Tag+")([-\\s\\w]*)((?:[a-zA-Z0-9][-_\\s]*){0})");
        Matcher m = p.matcher((CharSequence) outputMQXML);
        StringBuffer maskedResult = new StringBuffer();
        while (m.find()) 
        {
            String thisMask = m.group(1).replaceAll("[^-_\\s]", "*");
            m.appendReplacement(maskedResult, thisMask + "$2");
        }
        m.appendTail(maskedResult);
        return maskedResult.toString();
    }
	public void enableControl(String strFields, IFormReference iformObj)
	{
		String arrFields[] = strFields.split(",");
		for(int idx=0;idx<arrFields.length;idx++)
		{
			try
			{			
				//iformObj.getIFormControl(arrFields[idx]).getM_objControlStyle().setM_strEnable("true");
				iformObj.setStyle(arrFields[idx], "disable", "false");
			}
			catch(Exception ex)
			{
				TS.printException(ex);
			}	
		}
	}
	
	public void disableControl(String strFields, IFormReference iformObj)
	{
		String arrFields[] = strFields.split(",");
		for(int idx=0;idx<arrFields.length;idx++)
		{
			try
			{			
				//iformObj.getIFormControl(arrFields[idx]).getM_objControlStyle().setM_strEnable("false");
				iformObj.setStyle(arrFields[idx], "disable", "true");
			}
			catch(Exception ex)
			{
				TS.printException(ex);
			}	
		}
	}
	public void clearValue(String strFields, IFormReference iformObj)
	{
		String arrFields[] = strFields.split(",");
		for(int idx=0;idx<arrFields.length;idx++)
		{
			try
			{			
				iformObj.setValue(arrFields[idx], "");
			}
			catch(Exception ex)
			{
				TS.printException(ex);
			}	
		}
		
	}
	
	public void lockControl(String strFields, IFormReference iformObj)
	{
		String arrFields[] = strFields.split(",");
		for(int idx=0;idx<arrFields.length;idx++)
		{
			try
			{			
				iformObj.getIFormControl(arrFields[idx]).getM_objControlStyle().setM_strReadOnly("true");
			}
			catch(Exception ex)
			{
				TS.printException(ex);
			}	
		}
	}
	
	public void unlockControl(String strFields, IFormReference iformObj)
	{
		String arrFields[] = strFields.split(",");
		for(int idx=0;idx<arrFields.length;idx++)
		{
			try
			{			
				iformObj.getIFormControl(arrFields[idx]).getM_objControlStyle().setM_strReadOnly("false");
			}
			catch(Exception ex)
			{
				TS.printException(ex);
			}	
		}
	}
	
	public String getSessionId(IFormReference iformObj)
	{
		return ((iformObj).getObjGeneralData()).getM_strDMSSessionId();
	}
	
	public String getItemIndex(IFormReference iformObj)
	{
		return ((iformObj).getObjGeneralData()).getM_strFolderId();
	}
	
	public static String getWorkitemName(IFormReference iformObj)
	{
		return ((iformObj).getObjGeneralData()).getM_strProcessInstanceId();
	}
	
	public void setControlValue(String controlName, String controlValue, IFormReference iformObj)
	{
		iformObj.setValue(controlName,controlValue);
	}
	
	public String getCabinetName(IFormReference iformObj)
	{
		return (String)iformObj.getCabinetName();	
	}
	
	public String getUserName(IFormReference iformObj)
	{
		return (String)iformObj.getUserName();			
	}
	
	public String getActivityName(IFormReference iformObj)
	{
		return (String)iformObj.getActivityName();		
	}
	
	public String getControlValue(String controlName, IFormReference iformObj)
	{
//		return (String)EventHandler.iFormOBJECT.getControlValue(controlName);
		return (String)iformObj.getValue(controlName);
	}
	
	public boolean isControValueEmpty(String controlName, IFormReference iformObj)
	{
		String controlValue = getControlValue(controlName, iformObj);
		
		if(controlValue ==null || controlValue.equals(""))
			return true;
		else
			return false;
	}
	
	//******************************************************
	//Description            	:Method to get current date
	//******************************************************
	public String getCurrentDate(String outputFormat)
	{
		String current_date="";
		try
		{
			java.util.Calendar dateCreated1 = java.util.Calendar.getInstance();
			java.text.DateFormat df2 = new java.text.SimpleDateFormat(outputFormat);
			current_date = df2.format(dateCreated1.getTime());
		}
		catch(Exception e)
		{
			System.out.println("Exception in getting Current date :" +e);
		}
		return current_date;
	}

	
	public String ExecuteQueryOnServer(String sInputXML, IFormReference iformObj)
	{
		 try
        {
            TS.mLogger.debug("Server Ip :"+iformObj.getServerIp());
            TS.mLogger.debug("Server Port :"+iformObj.getServerPort());
            TS.mLogger.debug("Input XML :"+sInputXML);
           
            return NGEjbClient.getSharedInstance().makeCall(iformObj.getServerIp(), iformObj.getServerPort() + "", "WebSphere", sInputXML);
        }
        catch(Exception excp)
        {
        	TS.mLogger.debug("Exception occured in executing API on server :\n"+excp);
        	TS.printException(excp);
            return "Exception occured in executing API on server :\n"+excp;
        }       
    }

	public String ExecuteQuery_APProcedure(String ProcName,String Params, IFormReference iformObj)
	{
		try{
			
			String sInputXML = "<?xml version=\"1.0\"?>" +"\n"+
	                "<APProcedure_Input>" +"\n"+
					"<Option>APProcedure</Option>" +"\n"+
					"<ProcName>" + ProcName + "</ProcName>" +"\n"+
					"<Params>" + Params + "</Params>" +"\n"+
					"<EngineName>" + getCabinetName(iformObj) + "</EngineName>" +"\n"+
					"<SessionId>" + getSessionId(iformObj)+ "</SessionId>" +"\n"+
	                "</APProcedure_Input>";
			
			TS.mLogger.debug("Inside ExecuteQuery_APProcedure() [Input xml] \n: "+sInputXML);

			return ExecuteQueryOnServer(sInputXML, iformObj);
		} 
		catch (Exception e) 
		{
			TS.printException(e);
			return "";
		}			
	}	
	
	public String ExecuteQuery_APSelect(String sQuery, IFormReference iformObj)
	{
		try{
			WFInputXml wfInputXml = new WFInputXml();

			wfInputXml.appendStartCallName("APSelect", "Input");
			wfInputXml.appendTagAndValue("Query", sQuery);
			wfInputXml.appendTagAndValue("EngineName", getCabinetName(iformObj));
			wfInputXml.appendTagAndValue("SessionId", getSessionId(iformObj));
			wfInputXml.appendEndCallName("APSelect", "Input");
			String sInputXML= wfInputXml.toString();

			TS.mLogger.debug("Inside ExecuteQuery_APSelect [InputXml]:\n "+sInputXML);

			return ExecuteQueryOnServer(sInputXML, iformObj);
		} 
		catch (Exception e) 
		{
			TS.printException(e);
			return "";
		}			
	}

	public String ExecuteQuery_APSelectWithColumnNames(String sQuery, IFormReference iformObj)
	{
		try{
			WFInputXml wfInputXml = new WFInputXml();
			wfInputXml.appendStartCallName("APSelectWithColumnNames", "Input");
			wfInputXml.appendTagAndValue("Query", sQuery);
			wfInputXml.appendTagAndValue("EngineName", getCabinetName(iformObj));
			wfInputXml.appendTagAndValue("SessionId", getSessionId(iformObj));
			wfInputXml.appendEndCallName("APSelectWithColumnNames", "Input");
			String sInputXML= wfInputXml.toString();

			TS.mLogger.debug("Inside ExecuteQuery_APSelectWithColumnNames [InputXml]:\n "+sInputXML);

			return ExecuteQueryOnServer(sInputXML, iformObj);
		} 
		catch (Exception e) 
		{
			TS.printException(e);
			return "";
		}			
	}

	public String ExecuteQuery_APUpdate(String tableName, String columnName, String strValues, String sWhere, IFormReference iformObj)
	{
		try{
			WFInputXml wfInputXml = new WFInputXml();
			if (strValues == null)
			{
				strValues = "''";
			}
			wfInputXml.appendStartCallName("APUpdate", "Input");
			wfInputXml.appendTagAndValue("TableName", tableName);
			wfInputXml.appendTagAndValue("ColName", columnName);
			wfInputXml.appendTagAndValue("Values", strValues);
			wfInputXml.appendTagAndValue("WhereClause", sWhere);
			wfInputXml.appendTagAndValue("EngineName", getCabinetName(iformObj));
			wfInputXml.appendTagAndValue("SessionId", getSessionId(iformObj));
			wfInputXml.appendEndCallName("APUpdate", "Input");

			String sInputXML= wfInputXml.toString();

			TS.mLogger.debug("Inside ExecuteQuery_APUpdate [InputXml]:\n "+sInputXML);

			return ExecuteQueryOnServer(sInputXML, iformObj);
		} 
		catch (Exception e) 
		{
			TS.printException(e);
			return "";
		}			
	}

	public  String ExecuteQuery_APInsert(String tableName, String columnName, String strValues, IFormReference iformObj)
	{
		TS.mLogger.debug("Inside ExecuteQuery_APInsert()");
		try {
			WFInputXml wfInputXml = new WFInputXml();
			wfInputXml.appendStartCallName("APInsert", "Input");
			wfInputXml.appendTagAndValue("TableName", tableName);
			wfInputXml.appendTagAndValue("ColName", columnName);
			wfInputXml.appendTagAndValue("Values", strValues);
			wfInputXml.appendTagAndValue("EngineName", getCabinetName(iformObj));
			wfInputXml.appendTagAndValue("SessionId",getSessionId(iformObj));//added temp till sessionId is not available
			wfInputXml.appendEndCallName("APInsert", "Input");

			String sInputXML= wfInputXml.toString();

			TS.mLogger.debug("Inside ExecuteQuery_APInsert [InputXml]:\n "+sInputXML);

			return ExecuteQueryOnServer(sInputXML, iformObj);
			
		} 
		catch (Exception e) 
		{
			TS.printException(e);
			return "";
		}			

	}

	public String getTagValue(String xml, String tag) 
	{   
		try
		{
			Document doc = getDocument(xml);
			NodeList nodeList = doc.getElementsByTagName(tag);
	
			int length = nodeList.getLength();
			
			if (length > 0) 
			{
				Node node =  nodeList.item(0);
				if (node.getNodeType() == Node.ELEMENT_NODE) 
				{
					NodeList childNodes = node.getChildNodes();
					String value = "";
					int count = childNodes.getLength();
					for (int i = 0; i < count; i++) 
					{
						Node item = childNodes.item(i);
						if (item.getNodeType() == Node.TEXT_NODE) 
						{
							value += item.getNodeValue();
						}
					}
					return value;
				} 
				else if (node.getNodeType() == Node.TEXT_NODE) 
				{
					return node.getNodeValue();
				}	
			}
		}
		catch(Exception e)
		{
			TS.printException(e);
		}
	return "";
	}
	
	public String getTagValue(Node node, String tag)
	{
		// TODO Auto-generated method stub
		String value = "";

		NodeList nodeList = node.getChildNodes();
		int length = nodeList.getLength();

		for (int i = 0; i < length; ++i) {
			Node child = nodeList.item(i);

			if (child.getNodeType() == Node.ELEMENT_NODE && child.getNodeName().equalsIgnoreCase(tag)) {
				return child.getTextContent();
			}

		}
		return value;
	}

	public Document getDocument(String xml) throws ParserConfigurationException, SAXException, IOException
	{
		// Step 1: create a DocumentBuilderFactory
		DocumentBuilderFactory dbf =
				DocumentBuilderFactory.newInstance();

		// Step 2: create a DocumentBuilder
		DocumentBuilder db = dbf.newDocumentBuilder();

		// Step 3: parse the input file to get a Document object
		Document doc = db.parse(new InputSource(new StringReader(xml)));
		return doc;
	}
	
	public NodeList getNodeListFromDocument(Document doc,String identifier)
	{
		NodeList records = doc.getElementsByTagName(identifier);
		return records;
	}

	
	
	public String getGridDataXML(JSONArray jsonArray )
	{
		TS.mLogger.debug("Inside getGridDataXML method ... ");
		String xmlData="";
		
		try
		{
			Iterator it = jsonArray.iterator();			
			
			List<TreeMap<String,String>> list = new ArrayList<TreeMap<String,String>>();
			
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		    DocumentBuilder db = dbf.newDocumentBuilder();

		    Document document = db.newDocument();

		    Element root = document.createElement("ListItems"); 
		    document.appendChild(root);
		    
		    Element totalRecords = document.createElement("TotalRetrieved"); 
		    totalRecords.appendChild(document.createTextNode(jsonArray.size()+""));  
		    root.appendChild(totalRecords);   
		    
			int i =0;
			 while (it.hasNext()) 
			 {
				 TS.mLogger.debug("Loop ::"+i++);
				 TreeMap<String,String> content = new TreeMap<String,String>();
				 JSONObject obj = (JSONObject) it.next();
				 for (Object e : obj.entrySet()) 
				 {
					    Map.Entry entry = (Map.Entry) e;
					    content.put(String.valueOf(entry.getKey()), entry.getValue().toString());
				 }
				 
				TS.mLogger.debug("Content ::"+content);
		    	Element listItem = document.createElement("ListItem"); 
		    	//root.appendChild(listItem);
		    	
			    for(String e  : content.keySet())
			    {    
			    	TS.mLogger.debug("Map Loop ::"+i+"           Key:"+e+"        Value:"+content.get(e));
			        Element tag = document.createElement(e);
			        String tagValue = content.get(e);
			        
			        if(tagValue==null)
			        	tagValue="";
			        tag.appendChild(document.createTextNode(tagValue));
			        listItem.appendChild(tag);
			    }
			    root.appendChild(listItem);   
				 
		     }
			
			TransformerFactory tf = TransformerFactory.newInstance();
		    Transformer transformer;
		    
		    transformer = tf.newTransformer();
		    StringWriter writer = new StringWriter();
		    transformer.transform(new DOMSource(document), new StreamResult(writer));
		    xmlData = writer.getBuffer().toString();
		    xmlData = xmlData.replace("<?xml version=\"1.0\" encoding=\"UTF-8\"?>","");
		    TS.mLogger.debug("Output data :"+xmlData);
		}
		catch(Exception exc)
		{
			TS.printException(exc);
		}
		
		return xmlData;
	}
	
	public String SearchExistingDoc(IFormReference iformObj,String pid, String FrmType, String sCabname, String sSessionId, String sJtsIp, int iJtsPort_int, String sFilepath) 
	{
		try 
		{
			String strFolderIndex="";
			String strImageIndex="";
			
			String strInputQry1="SELECT FOLDERINDEX,ImageVolumeIndex FROM PDBFOLDER WITH(NOLOCK) WHERE NAME='" + pid + "'";
			
			short iJtsPort = (short) iJtsPort_int;
			
			TS.mLogger.debug("sInputXML: "+strInputQry1);
			
			List<List<String>> dataFromDB = iformObj.getDataFromDB(strInputQry1);
			for (List<String> tableFrmDB : dataFromDB) {
				strFolderIndex = tableFrmDB.get(0).trim();
				//strImageIndex = tableFrmDB.get(1).trim();
				strImageIndex = Integer.toString(iformObj.getObjGeneralData().getM_iVolId());
			}
			TS.mLogger.debug("strFolderIndex: "+strFolderIndex);
			TS.mLogger.debug("strImageIndex: "+strImageIndex);
			
			IFormXmlResponse xmlParserData = new IFormXmlResponse();
			
			if (!(strFolderIndex.equalsIgnoreCase("") && strImageIndex.equalsIgnoreCase(""))) 
			{
				
				String strInputQry2="SELECT a.documentindex,b.ParentFolderIndex FROM PDBDOCUMENT A WITH (NOLOCK), PDBDOCUMENTCONTENT B WITH (NOLOCK)" + "WHERE A.DOCUMENTINDEX= B.DOCUMENTINDEX AND A.NAME IN ('" + FrmType + "','') AND B.PARENTFOLDERINDEX ='" + strFolderIndex + "'";
				TS.mLogger.debug("sInputXML: "+strInputQry2);
				
				List<List<String>> dataFromDB2 = iformObj.getDataFromDB(strInputQry2);
				ArrayList<String> strdocumentindex = new ArrayList<String>(dataFromDB2.size());
				ArrayList<String> strParentFolderIndex = new ArrayList<String>(dataFromDB2.size());

				for (List<String> tableFrmDB2 : dataFromDB2) {
					
					strdocumentindex.add(tableFrmDB2.get(0).trim());
					strParentFolderIndex.add(tableFrmDB2.get(1).trim());
				}
				TS.mLogger.debug("strdocumentindex: "+strdocumentindex);
				TS.mLogger.debug("strParentFolderIndex: "+strParentFolderIndex);
				
				TS.mLogger.debug("dataFromDB2.size();: "+dataFromDB2.size());
								
				TS.mLogger.debug("dataFromDB2.isEmpty: "+dataFromDB2.isEmpty());
				try 
				{
					TS.mLogger.debug("Inside Adding PN File: ");
					TS.mLogger.debug("sFilepath: "+sFilepath);
					String filepath = sFilepath;
					
					File newfile = new File(filepath);
					String name = newfile.getName();
					String ext = "";
					String sMappedInputXml="";
					if (name.contains(".")) {
						ext = name.substring(name.lastIndexOf("."), name.length());
					}
					JPISIsIndex ISINDEX = new JPISIsIndex();
					JPDBRecoverDocData JPISDEC = new JPDBRecoverDocData();
					String strDocumentPath = sFilepath;
					File processFile = null;
					long lLngFileSize = 0L;
					processFile = new File(strDocumentPath);
					
					lLngFileSize = processFile.length();
					String lstrDocFileSize = "";
					lstrDocFileSize = Long.toString(lLngFileSize);
					
					String createdbyappname = "";
					createdbyappname = ext.replaceFirst(".", "");
					Short volIdShort = Short.valueOf(strImageIndex);
					
					TS.mLogger.debug("lLngFileSize: --"+lLngFileSize);
					if (lLngFileSize != 0L)
					{
						TS.mLogger.debug("sJtsIp --"+sJtsIp+" iJtsPort-- "+iJtsPort+" sCabname--"+sCabname+" volIdShort.shortValue() --"+volIdShort.shortValue()+" strDocumentPath--"+strDocumentPath+" JPISDEC --"+JPISDEC+"  ISINDEX-- "+ISINDEX);
						CPISDocumentTxn.AddDocument_MT(null, sJtsIp, iJtsPort, sCabname, volIdShort.shortValue(), strDocumentPath, JPISDEC, "", ISINDEX);
						
					}
					TS.mLogger.debug("dataFromDB2.size(): --"+dataFromDB2.size());
					if (dataFromDB2.size() > 0) 
					{  
						SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");
						Date date = new Date(System.currentTimeMillis());
						String strCurrDateTime = formatter.format(date);
						for(int i=0;i<dataFromDB2.size();i++)
						{
							TS.mLogger.debug("NGOChangeDocumentProperty_Input section");
							 sMappedInputXml = "<?xml version=\"1.0\"?>"
									+ "<NGOChangeDocumentProperty_Input>"
									+ "<Option>NGOChangeDocumentProperty</Option>"
									+ "<CabinetName>" + sCabname + "</CabinetName>"
									+ "<UserDBId>" + sSessionId + "</UserDBId><Document><DocumentIndex>" + strdocumentindex.get(i) + "</DocumentIndex><NoOfPages>1</NoOfPages>"
									+ "<DocumentName>" + FrmType + "</DocumentName>"
									+ "<AccessDateTime>"+strCurrDateTime+"</AccessDateTime>"
									+ "<ExpiryDateTime>2099-12-12 0:0:0.0</ExpiryDateTime>"
									+ "<CreatedByAppName>" + createdbyappname + "</CreatedByAppName>"
									+ "<VersionFlag>N</VersionFlag>"
									+ "<AccessType>S</AccessType>"
									+ "<ISIndex>" + ISINDEX.m_nDocIndex + "#" + ISINDEX.m_sVolumeId + "</ISIndex><TextISIndex>0#0#</TextISIndex>"
									+ "<DocumentType>N</DocumentType>"
									+ "<DocumentSize>" + lstrDocFileSize + "</DocumentSize><Comment>" + createdbyappname + "</Comment><RetainAnnotation>N</RetainAnnotation></Document>"
									+ "</NGOChangeDocumentProperty_Input>";    
						}
					} 
					else 
					{
						
						sMappedInputXml="<?xml version=\"1.0\"?>"+
									"<NGOAddDocument_Input>"+ 
									"<Option>NGOAddDocument</Option>"+ 
									"<CabinetName>"+sCabname+"</CabinetName>"+ 
									"<UserDBId>"+sSessionId+"</UserDBId>" + 
									"<GroupIndex>0</GroupIndex>" +
									"<VersionFlag>Y</VersionFlag>" +
									"<ParentFolderIndex>"+strFolderIndex+"</ParentFolderIndex>" +
									"<DocumentName>"+FrmType+"</DocumentName>"+
									"<CreatedByAppName>"+createdbyappname+"</CreatedByAppName>" +
									"<Comment>"+FrmType+"</Comment>" +
									"<VolumeIndex>"+ISINDEX.m_sVolumeId+"</VolumeIndex>"+
									"<FilePath>"+strDocumentPath+"</FilePath>"+
									"<ISIndex>"+ISINDEX.m_nDocIndex+"#"+ISINDEX.m_sVolumeId+"</ISIndex>" + 
									"<NoOfPages>1</NoOfPages>" + 
									"<DocumentType>N</DocumentType>" +
									"<DocumentSize>"+lstrDocFileSize+"</DocumentSize>" +
									"</NGOAddDocument_Input>";
					
					}
					TS.mLogger.debug("Document Addition sInputXML: "+sMappedInputXml);
					//String sOutputXml = WFCustomCallBroker.execute(sMappedInputXml, sJtsIp, iJtsPort, 1);
					String sOutputXML = ExecuteQueryOnServer(sMappedInputXml, iformObj);
					xmlParserData.setXmlString((sOutputXML));
					TS.mLogger.debug("Document Addition sOutputXml: "+sOutputXML);
					String status_D = xmlParserData.getVal("Status");
					if(status_D.equalsIgnoreCase("0")){
						//deleteLocalDocument(sFilepath);
						return sOutputXML;
					} else {
						return "Error in Document Addition";
					}
				} 
				catch (JPISException e) 
				{
					return "Error in Document Addition at Volume";
				} 
				catch (Exception e) 
				{
					return "Exception Occurred in Document Addition";
				}
					
			}
			return "Any Error occurred in Addition of Document";
		} 
		catch (Exception e) 
		{
			return "Exception Occurred in SearchDocument";
		}
	}
	public String getWFUploadWorkItemXML(IFormReference ifr,String processDefID, String attributeTag)
	{
		String cabinetName = ifr.getCabinetName();
		String sessionID = getSessionId(ifr);
		TS.mLogger.info("cabinetName: "+cabinetName +", sessionID: "+sessionID);

		return  "<?xml version=\"1.0\"?>"+
					"<WFUploadWorkItem_Input>"+
					"<Option>WFUploadWorkItem</Option>"+
					"<EngineName>"+cabinetName+"</EngineName>"+
					"<SessionId>"+sessionID+"</SessionId>"+
					"<ValidationRequired><ValidationRequired>"+
					"<ProcessDefId>"+processDefID+"</ProcessDefId>"+
					"<DataDefName></DataDefName>"+
					"<Fields></Fields>"+
					"<InitiateAlso>N</InitiateAlso>"+
					"<Attributes>"+attributeTag+"</Attributes>"+
					"</WFUploadWorkItem_Input>";
	}
	
	public void isSRORaised(IFormReference iformObj)
	{
		if("WI Created".equalsIgnoreCase((String) iformObj.getValue("SRO_STATUS"))) 
		{
			iformObj.setStyle("SRO_REQUEST_TYPE","disable","true");
			iformObj.setStyle("SRO_TEAM_CODE","disable","true");
			iformObj.setStyle("SRO_REMARKS","disable","true");
			iformObj.setStyle("SERVICE_TYPE","disable","true");
			iformObj.setStyle("SROBTN","disable","true");
			iformObj.setStyle("CARD_TYPE","disable","true");
			
		}
	}
	
	public void cardTypeValidation(IFormReference iform)
	{
		String serviceType=(String) iform.getValue("SERVICE_TYPE");
		if("Card Dispute".equalsIgnoreCase(serviceType)) 
		{
			iform.setStyle("CARD_TYPE","visible","true");
		}
		else
		{
			iform.setStyle("CARD_TYPE","visible","false");
		}
	
	}
	public void userTypeValidation(IFormReference iform)
	{
		String serviceType=(String) iform.getValue("SERVICE_TYPE");
		if("ATM Dispute".equalsIgnoreCase(serviceType)) 
		{
			iform.setStyle("USER_TYPE","visible","true");
		}
		else 
		{
			iform.setStyle("USER_TYPE","visible","false");
		}
	
	}
	public void cscValidation(IFormReference iform)
	{
		String cscTypeOfRequest=(String) iform.getValue("CSC_REQUEST_TYPE");
		//Type of reversal validation
		if("Reversal".equalsIgnoreCase(cscTypeOfRequest) || "Cancellation with Reversal".equalsIgnoreCase(cscTypeOfRequest) || "Cancellation with Reversal and Other Charges".equalsIgnoreCase(cscTypeOfRequest) )
		{
			iform.setStyle("Q_NG_TS_CSC_REVERSAL_DTLS","visible","true");
			iform.setStyle("Q_NG_TS_CSC_REVERSAL_DTLS","mandatory","true");
			iform.setStyle("CSC_AMT_AED","disable","false");
			iform.setStyle("CSC_NO_OF_MONTHS","disable","false");
			iform.setStyle("CSC_NO_OF_MONTHS","mandatory","true");
			/*if(iform.getActivityName()=="Initiation")
			{
				
			}*/
			
			//iform.setValue("Q_NG_TS_CSC_REVERSAL_DTLS", "");
		}
		else 
		{
			iform.setStyle("Q_NG_TS_CSC_REVERSAL_DTLS","visible","false");
			iform.setStyle("CSC_AMT_AED","disable","true");
			iform.setStyle("CSC_NO_OF_MONTHS","disable","true");
			iform.setStyle("CSC_NO_OF_MONTHS","mandatory","false");
		}
		// Credit Shield Amount && No.of Months if("Cancellation".equalsIgnoreCase(cscTypeOfRequest)) 
		
	}
	public void RPValidation(IFormReference iform)
	{
		String RPTypeOfRequest=(String) iform.getValue("RP_REQUEST_TYPE");
		//Type of reversal validation
		if("Reversal".equalsIgnoreCase(RPTypeOfRequest) || "Cancellation with Reversal".equalsIgnoreCase(RPTypeOfRequest))
		{
			iform.setStyle("Q_NG_TS_RP_REVERSAL_DTLS","visible","true");
			iform.setStyle("Q_NG_TS_RP_REVERSAL_DTLS","mandatory","true");
		}
		
		else
		{
			iform.setStyle("Q_NG_TS_RP_REVERSAL_DTLS","visible","false");
		}
	}
	public void ServiceVisibility(IFormReference iform, String ServiceType) 
	{
		if(ServiceType.equalsIgnoreCase("Credit Shield Cancellation"))
		{
			TS.mLogger.debug("Inside SeviceType " +ServiceType); 
			iform.setStyle("MODE_OF_SEARCH", "visible", "false");
			iform.setStyle("HEADER_CARD_NO","visible","true");
			iform.setStyle("HEADER_CIF","visible","false");
			iform.setStyle("creditShieldCancellation","visible","true");
			iform.setStyle("creditShieldInsuranceClaim","visible","false");
			iform.setStyle("RAKProtect","visible","false");
			iform.setStyle("cardDispute","visible","false");
			iform.setStyle("ATMDispute","visible","false");
			if("Y".equalsIgnoreCase((String) iform.getValue("CSC_MOB_CONFIRMED_FLAG"))) 
			{
				TS.mLogger.debug("Inside CSC MOB Confirmed " +iform.getValue("CSC_MOB_CONFIRMED_FLAG"));
				iform.setStyle("CSC_COUNTRY_MOBILE_CODE","visible","false");
				iform.setStyle("CSC_ALTERNATE_MOB_NO","visible","false");
			}
			else 
			{
				iform.setStyle("CSC_COUNTRY_MOBILE_CODE","visible","true");
				iform.setStyle("CSC_ALTERNATE_MOB_NO","visible","true");
			}
			String cscTypeOfRequest=(String) iform.getValue("CSC_REQUEST_TYPE");
			if("Reversal".equalsIgnoreCase(cscTypeOfRequest) || "Cancellation with Reversal".equalsIgnoreCase(cscTypeOfRequest) || "Cancellation with Reversal and Other Charges".equalsIgnoreCase(cscTypeOfRequest) )
			{
				iform.setStyle("Q_NG_TS_CSC_REVERSAL_DTLS","visible","true");
				iform.setStyle("Q_NG_TS_CSC_REVERSAL_DTLS","mandatory","true");
			}
			
			//cscValidation(iform);
			
		}
		else if(ServiceType.equalsIgnoreCase("Credit Shield Insurance Claim"))
		{
			TS.mLogger.debug("Inside SeviceType " +ServiceType);
			iform.setStyle("MODE_OF_SEARCH", "visible", "false");
			iform.setStyle("HEADER_CARD_NO","visible","true");
			iform.setStyle("HEADER_CIF","visible","false");
			iform.setStyle("creditShieldInsuranceClaim","visible","true");
			iform.setStyle("creditShieldCancellation","visible","false");
			iform.setStyle("RAKProtect","visible","false");
			iform.setStyle("cardDispute","visible","false");
			iform.setStyle("ATMDispute","visible","false");
		}
		else if(ServiceType.equalsIgnoreCase("RAK Protect"))
		{
			TS.mLogger.debug("Inside SeviceType " +ServiceType);
			iform.setStyle("MODE_OF_SEARCH", "visible", "false");
			iform.setStyle("HEADER_CARD_NO","visible","true");
			iform.setStyle("HEADER_CIF","visible","false");
			iform.setStyle("RAKProtect","visible","true");
			iform.setStyle("creditShieldCancellation","visible","false");
			iform.setStyle("creditShieldInsuranceClaim","visible","false");
			iform.setStyle("cardDispute","visible","false");
			iform.setStyle("ATMDispute","visible","false");
			//typeOfRequest(iform,ServiceType);
			RPValidation(iform);
		}
		else if(ServiceType.equalsIgnoreCase("Card Dispute"))
		{
			TS.mLogger.debug("Inside SeviceType " +ServiceType);
			iform.setStyle("MODE_OF_SEARCH", "visible", "false");
			iform.setStyle("HEADER_CARD_NO","visible","true");
			iform.setStyle("HEADER_CIF","visible","false");
			iform.setStyle("cardDispute","visible","true");
			iform.setStyle("creditShieldCancellation","visible","false");
			iform.setStyle("creditShieldInsuranceClaim","visible","false");
			iform.setStyle("RAKProtect","visible","false");
			iform.setStyle("ATMDispute","visible","false");
			new TS_Integration().isSRORaised(iform);
			cardTypeValidation(iform);
		}
		else if(ServiceType.equalsIgnoreCase("ATM Dispute"))
		{
			TS.mLogger.debug("Inside SeviceType " +ServiceType);
			iform.setStyle("MODE_OF_SEARCH","visible","true");
			//iform.setStyle("HEADER_CARD_NO","visible","false");
			//iform.setStyle("HEADER_CIF","visible","false");
			//iform.setStyle("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS","visible","true");
			iform.setStyle("ATMDispute","visible","true");
			iform.setStyle("creditShieldCancellation","visible","false");
			iform.setStyle("creditShieldInsuranceClaim","visible","false");
			iform.setStyle("RAKProtect","visible","false");
			iform.setStyle("cardDispute","visible","false");
			userTypeValidation(iform);
			String relatedTo="";
			relatedTo=(String) iform.getValue("AD_RELATEDTO");
			
			if(iform.getActivityName()=="Initiation") 
			{
				if("Withdrawal".equalsIgnoreCase(relatedTo))
				 {
					iform.setStyle("AD_AMT_WITHDRAWAL", "disable", "false");
					iform.setStyle("AD_AMT_DEPOSITED", "disable", "true");
				}
				else if("Cash Deposit".equalsIgnoreCase(relatedTo)|| "Cheque Deposit".equalsIgnoreCase(relatedTo)) 
				{
					iform.setStyle("AD_AMT_WITHDRAWAL", "disable", "true");
					iform.setStyle("AD_AMT_DEPOSITED", "disable", "false");
				}
				else 
				{
					iform.setStyle("AD_AMT_WITHDRAWAL", "disable", "true");
					iform.setStyle("AD_AMT_DEPOSITED", "disable", "true");
				}
			}
			if(!"".equalsIgnoreCase((String) iform.getValue("MODE_OF_SEARCH")))
			{
				if("Card".equalsIgnoreCase((String) iform.getValue("MODE_OF_SEARCH")))
				{
					iform.setStyle("HEADER_CIF", "visible", "false");
					iform.setStyle("HEADER_CARD_NO", "visible", "true");
					iform.setStyle("CARD_TYPE","visible","true");
				}
				else
				{
					iform.setStyle("HEADER_CIF", "visible", "true");
					iform.setStyle("HEADER_CARD_NO", "visible", "false");
					iform.setStyle("CARD_TYPE","visible","false");
				}
				
			}
			
		}
		
	}
	public void typeOfRequest(IFormReference iform, String ServiceType)
	{
		try 
		{				
			List ReqType = iform
				.getDataFromDB("SELECT distinct(TYPE_OF_REQUEST) FROM NG_TS_TYPE_OF_REQUEST_MASTER WITH(NOLOCK) WHERE SERVICE_TYPE='"+ServiceType+"' and ISACTIVE='Y'");
			TS.mLogger.debug("WINAME : "+getWorkitemName(iform)+", ReqType "+ReqType);
			String value="";
			String id="";
			if("Credit Shield Cancellation".equalsIgnoreCase(ServiceType))
			{
				id="CSC_REQUEST_TYPE";
			}
			else
			{
				id="RP_REQUEST_TYPE";
			}
			iform.clearCombo(id);
			for(int i=0;i<ReqType.size();i++)
			{
				List<String> arr1=(List)ReqType.get(i);
				value=arr1.get(0);
				iform.addItemInCombo(id,value,value);
				TS.mLogger.debug("Reqtype : "+value);
			}	
		} 
		catch (Exception e) {
			TS.mLogger.debug("WINAME : "+getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+", Exception in Decision drop down load " + e.getMessage());
		}
	}
	public void enableTSControl(String workstepName,String ServiceType,IFormReference iform)
	{
		String idS="";
		if(!"".equalsIgnoreCase(ServiceType))
		{
			ServiceType=ServiceType.toUpperCase().replace(' ' ,'_');
			TS.mLogger.debug("ServiceTYpe " +ServiceType); 
			idS=TS.properties.getProperty(ServiceType);
			TS.mLogger.debug(" " +idS);
			if(!"".equalsIgnoreCase(idS))
			{
				enableControl(idS, iform);
			}
		}
		else if(!"".equalsIgnoreCase(workstepName))
		{
			TS.mLogger.debug("workstep_Name " +workstepName); 
			idS=TS.properties.getProperty(workstepName);
			TS.mLogger.debug(" " +idS);
			if(!"".equalsIgnoreCase(idS))
			{
				enableControl(idS, iform);
			}
		}
	}
	public void applyMandatory(IFormReference iform,String Workstep,String ServiceType )
	{
		if((Workstep.equalsIgnoreCase("Initiation")) || (Workstep.equalsIgnoreCase("Branch_Return"))) 
		{
			TS.mLogger.debug("Inside ApplyMandatory for WI_Name " +Workstep);
			if(ServiceType.equalsIgnoreCase("Credit Shield Cancellation"))
			{
				TS.mLogger.debug("Inside SeviceType " +ServiceType); 
				iform.setStyle("CSC_REQUEST_TYPE","mandatory","true");
				iform.setStyle("CSC_NO_OF_MONTHS","mandatory","true");
			}
			else if(ServiceType.equalsIgnoreCase("Credit Shield Insurance Claim"))
			{
				TS.mLogger.debug("Inside SeviceType " +ServiceType);
				iform.setStyle("CSI_TYPEOFCLAIM","mandatory","true");
				iform.setStyle("CSI_EVENTDATE","mandatory","true");
				iform.setStyle("CSI_ELIGIBILITY_CC_FLAG","mandatory","true");
				iform.setStyle("CSI_STATUS_FLAGGING_CC","mandatory","true");
			}
			else if(ServiceType.equalsIgnoreCase("RAK Protect"))
			{
				TS.mLogger.debug("Inside SeviceType " +ServiceType);
				iform.setStyle("RP_REQUEST_TYPE","mandatory","true");
			}
			/*else if(ServiceType.equalsIgnoreCase("Card Dispute"))
			{
				TS.mLogger.debug("Inside SeviceType " +ServiceType);
				iform.setStyle("HEADER_CARD_NO","visible","true");
				iform.setStyle("HEADER_CIF","visible","false");
				iform.setStyle("cardDispute","visible","true");
				iform.setStyle("creditShieldCancellation","visible","false");
				iform.setStyle("creditShieldInsuranceClaim","visible","false");
				iform.setStyle("RAKProtect","visible","false");
				iform.setStyle("ATMDispute","visible","false");
			}*/
			else if(ServiceType.equalsIgnoreCase("ATM Dispute"))
			{
				TS.mLogger.debug("Inside SeviceType " +ServiceType);
				iform.setStyle("AD_REQ_TYPE","mandatory","true");
				iform.setStyle("AD_LOCATION","mandatory","true");
				iform.setStyle("AD_DATE","mandatory","true");
				iform.setStyle("AD_TIME","mandatory","true");
				iform.setStyle("AD_AMT_DISPUTE","mandatory","true");
			}
		}
		if((Workstep.equalsIgnoreCase("Tele_Sales_Maker")) || (Workstep.equalsIgnoreCase("Card_Settlement_Maker")) || (Workstep.equalsIgnoreCase("Card_Maintenance_Maker"))) 
		{
			iform.setStyle("CSC_NO_OF_MONTHS","mandatory","true");
		}
		//Manthan
		else if(Workstep.equalsIgnoreCase("Card_Dispute_Maker")){
			iform.setStyle("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS_CATEGORY","mandatory","true");
			iform.setStyle("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS_LOCATION","mandatory","true");
			iform.setStyle("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS_SERNO","mandatory","true");
			iform.setStyle("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS_ARN","mandatory","true");	
		}
		
	}
	public static String getSLADate(String inputDatetimeStr,int days)
	{
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
        Date inputDateTime = new Date();
		try
		{
			inputDateTime = sdf.parse(inputDatetimeStr);
		} 
		catch (ParseException e) 
		{
			e.printStackTrace();
		}
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(inputDateTime);
        calendar.add(Calendar.DAY_OF_MONTH, days);
        
        Date newDateTime=calendar.getTime();
        String sladate=sdf1.format(newDateTime);
		          
		System.out.println(sladate);
			
		return sladate;
		
	}
	
}