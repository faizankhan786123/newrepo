package com.newgen.iforms.user;

import org.json.simple.JSONArray;
import java.util.List;
import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TS_Change extends TS_Common
{
	
	public String onChange(IFormReference iform, String controlName,String event, String data)
	{	
		String strReturn="";
		String serviceType=(String) iform.getValue("SERVICE_TYPE");
		String Workstep=iform.getActivityName();
		String clearValIds="";
		if("SERVICE_TYPE".equalsIgnoreCase(controlName))
		{
			
			clearValIds="HEADER_CIF,HEADER_CARD_NO,CARD_TYPE,CSC_AMT_AED,CSC_NO_OF_MONTHS,"
					+ "CSC_CANCELLATION_REMARKS,CSC_ALTERNATE_MOB_NO,CSC_REQUEST_TYPE,CSC_REQUEST_TYPE,"
					+ "Q_NG_TS_CSC_REVERSAL_DTLS,CSC_COUNTRY_MOBILE_CODE,CSI_TYPEOFCLAIM,"
					+ "CSI_EVENTDATE,CSI_ELIGIBILITY_CC_FLAG,CSI_ELIGIBILITY_LOAN_FLAG,"
					+ "CSI_INSURANCE_REMARKS,CSI_KIN_NAME,CSI_CONTACT_NO,CSI_EMAILID,"
					+ "CSI_GENERAL_STATUS_EVENT,CSI_GENERAL_STATUS_CURRENTLY,CSI_EVENT_STATUS,"
					+ "CSI_CURRENT_STATUS,CSI_ENROLLED_DATE,CSI_UNENROLLED_DATE,"
					+ "CSI_EVENT_AGE,CSI_UNENROLLING_REASON,CSI_STATUS_FLAGGING_CC,"
					+ "CSI_STATUS_FLAGGING_LOANS,RP_REQUEST_TYPE,Q_NG_TS_RP_REVERSAL_DTLS,"
					+ "SRO_REQUEST_TYPE,SRO_TEAM_CODE,SRO_REMARKS,Q_NG_TS_CD_REASON_DTLS,AD_REQ_TYPE,"
					+ "AD_LOCATION,AD_REMARKS,AD_NAME,AD_BANKNAME,AD_DATE,AD_TIME,AD_RELATEDTO,"
					+ "AD_ACC_NO,AD_AMT_DEPOSITED,AD_AMT_WITHDRAWAL,AD_AMT_DISPUTE,AD_CALLER_NAME,"
					+ "AD_CALLER_NO,CUSTOMER_NAME, MOBILE_NO, EMAIL_ID,CUSTOMER_TYPE,CARD_CRN_NO,"
					+ "EXPIRY_DATE,CIF_ID,GENERAL_STATUS,ELITE_CUST_NO,SOURCE_ID,EXT_NO,MOBILE_NO,EMAIL_ID,REJECT_REASON,OTHER_REJ_REASON,MODE_OF_SEARCH,CARD_DISPUTE_TYPE";
			
			clearValue(clearValIds,iform);
			iform.setStyle("CSC_COUNTRY_MOBILE_CODE","visible","false");
			iform.setStyle("CSC_ALTERNATE_MOB_NO","visible","false");
			iform.setStyle("MODE_OF_SEARCH", "visible", "false");
			iform.clearTable("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS1");
			
			/*---IN CASE OF SELECTED CARD TYPE----*/
			
			iform.setStyle("CUSTOMER_NAME", "mandatory", "false");
			iform.setStyle("MOBILE_NO", "mandatory", "false");
			iform.setStyle("EMAIL_ID", "mandatory", "false");
			iform.setStyle("CUSTOMER_NAME", "disable", "true");
			iform.setStyle("EXPIRY_DATE", "disable", "true");
			iform.setStyle("MOBILE_NO", "disable", "true");
			iform.setStyle("EMAIL_ID", "disable", "true");
			iform.setStyle("GENERAL_STATUS", "disable", "true");
			iform.setStyle("ELITE_CUST_NO", "disable", "true");
			iform.setStyle("CARD_CRN_NO", "disable", "true");
			iform.setStyle("CIF_ID", "disable", "true");
			iform.setStyle("CustomerSearch", "disable", "false");
			
			/*----------------------------*/
			
			if("ATM Dispute".equalsIgnoreCase(serviceType)) 
			{
				iform.setValue("MODE_OF_SEARCH","Card");
			}
			cardTypeValidation(iform);
			userTypeValidation(iform);
			ServiceVisibility(iform, serviceType);
			enableTSControl("",serviceType, iform);
			applyMandatory(iform,Workstep,serviceType);
		}
		else if("CSC_REQUEST_TYPE".equalsIgnoreCase(controlName))
		{
			iform.setValue("Q_NG_TS_CSC_REVERSAL_DTLS", "");
			iform.setValue("CSC_AMT_AED", "");
			iform.setValue("CSC_NO_OF_MONTHS", "");
			cscValidation(iform);	
		}
		else if("RP_REQUEST_TYPE".equalsIgnoreCase(controlName))
		{
			iform.setValue("Q_NG_TS_RP_REVERSAL_DTLS", "");
			RPValidation(iform);	
		}
		else if("CSC_MOB_CONFIRMED_FLAG_0".equalsIgnoreCase(controlName) || "CSC_MOB_CONFIRMED_FLAG_1".equalsIgnoreCase(controlName)) 
		{
			iform.setValue("CSC_COUNTRY_MOBILE_CODE", "");
			iform.setValue("CSC_ALTERNATE_MOB_NO", "");
			
			if("Y".equalsIgnoreCase((String) iform.getValue("CSC_MOB_CONFIRMED_FLAG"))) 
			{
				iform.setStyle("CSC_COUNTRY_MOBILE_CODE","visible","false");
				iform.setStyle("CSC_ALTERNATE_MOB_NO","visible","false");
				iform.setStyle("CSC_COUNTRY_MOBILE_CODE","mandatory","false");
				iform.setStyle("CSC_ALTERNATE_MOB_NO","mandatory","false");
			}
			else 
			{
				iform.setStyle("CSC_COUNTRY_MOBILE_CODE","visible","true");
				iform.setStyle("CSC_ALTERNATE_MOB_NO","visible","true");
				iform.setStyle("CSC_COUNTRY_MOBILE_CODE","mandatory","true");
				iform.setStyle("CSC_ALTERNATE_MOB_NO","mandatory","true");
			}
			return "";
		}
		else if("CSI_ELIGIBILITY_CC_FLAG".equalsIgnoreCase(controlName))
		{
			String csiCCFlag=(String) iform.getValue("CSI_ELIGIBILITY_CC_FLAG");
			if("Termination within 120 days".equalsIgnoreCase(csiCCFlag) || "Termination before 60 years of age".equalsIgnoreCase(csiCCFlag) || "Others".equalsIgnoreCase(csiCCFlag) || "Death at the age less than or equal to 65 years".equalsIgnoreCase(csiCCFlag) || "Un-enrolled Credit Shield SME Card".equalsIgnoreCase(csiCCFlag)) 
			{
				iform.setValue("CSI_STATUS_FLAGGING_CC", "Eligible");
			}
			else if("".equalsIgnoreCase(csiCCFlag) )
			{
				iform.setValue("CSI_STATUS_FLAGGING_CC", "");
			}
			else
			{
				iform.setValue("CSI_STATUS_FLAGGING_CC", "Not Eligible");
			}
		}
		else if("CSI_ELIGIBILITY_LOAN_FLAG".equalsIgnoreCase(controlName)) 
		{
			String csiLoanFlag=(String) iform.getValue("CSI_ELIGIBILITY_LOAN_FLAG");
			if("Death at the age is less than or equal to 70+12 months".equalsIgnoreCase(csiLoanFlag) || "Others".equalsIgnoreCase(csiLoanFlag)) 
			{
				iform.setValue("CSI_STATUS_FLAGGING_LOANS", "Eligible");
			}
			else if("".equalsIgnoreCase(csiLoanFlag) )
			{
				iform.setValue("CSI_STATUS_FLAGGING_LOANS", "");
			}
			else
			{
				iform.setValue("CSI_STATUS_FLAGGING_LOANS", "Not Eligible");
			}
		}
		
		else if("CSI_TYPEOFCLAIM".equalsIgnoreCase(controlName)) 
		{
			String csiTypeOfClaim=(String) iform.getValue("CSI_TYPEOFCLAIM");
			if("Death".equalsIgnoreCase(csiTypeOfClaim)) 
			{
				iform.setStyle("CSI_INSURANCE_REMARKS","mandatory","true");
				iform.setStyle("CSI_KIN_NAME","mandatory","true");
				iform.setStyle("CSI_CONTACT_NO","mandatory","true");
			}
			else
			{
				iform.setStyle("CSI_INSURANCE_REMARKS","mandatory","false");
				iform.setStyle("CSI_KIN_NAME","mandatory","false");
				iform.setStyle("CSI_CONTACT_NO","mandatory","false");
			}
		}
		else if("AD_LOCATION".equalsIgnoreCase(controlName))
		{
			String ATM_Location=(String) iform.getValue("AD_LOCATION");
			iform.setValue("AD_ATM_REMARKS","");
			if("Other_Other".equalsIgnoreCase(ATM_Location)) 
			{
				iform.setStyle("AD_ATM_REMARKS","disable","false");
				iform.setStyle("AD_ATM_REMARKS","mandatory","true");
				
			}
			else
			{
				iform.setStyle("AD_ATM_REMARKS","disable","true");
				iform.setStyle("AD_ATM_REMARKS","mandatory","false");
			}
		}
	
		else if("AD_RELATEDTO".equalsIgnoreCase(controlName)) 
		{
			iform.setValue("AD_AMT_WITHDRAWAL", "");
			iform.setValue("AD_AMT_DEPOSITED", "");
			String relatedTo=(String) iform.getValue("AD_RELATEDTO");
			if("Withdrawal".equalsIgnoreCase(relatedTo))
			{
				iform.setStyle("AD_AMT_WITHDRAWAL", "disable", "false");
				iform.setStyle("AD_AMT_DEPOSITED", "disable", "true");
				iform.setStyle("AD_AMT_WITHDRAWAL", "mandatory", "true");
				iform.setStyle("AD_AMT_DEPOSITED", "mandatory", "false");
			}
			else if("Cash Deposit".equalsIgnoreCase(relatedTo)|| "Cheque Deposit".equalsIgnoreCase(relatedTo)) {
				iform.setStyle("AD_AMT_WITHDRAWAL", "disable", "true");
				iform.setStyle("AD_AMT_DEPOSITED", "disable", "false");
				iform.setStyle("AD_AMT_DEPOSITED", "mandatory", "true");
				iform.setStyle("AD_AMT_WITHDRAWAL", "mandatory", "false");
			}
			else 
			{
				iform.setStyle("AD_AMT_WITHDRAWAL", "disable", "true");
				iform.setStyle("AD_AMT_DEPOSITED", "disable", "true");
				iform.setStyle("AD_AMT_WITHDRAWAL", "mandatory", "false");
				iform.setStyle("AD_AMT_DEPOSITED", "mandatory", "false");
			}
		}
		else if("CARD_TYPE".equalsIgnoreCase(controlName)) 
		{
			String CardType=(String) iform.getValue("CARD_TYPE");
			clearValue("CUSTOMER_NAME,EXPIRY_DATE,MOBILE_NO,EMAIL_ID,GENERAL_STATUS,ELITE_CUST_NO,CARD_CRN_NO,CIF_ID",iform);
			if("Prepaid Card".equalsIgnoreCase(CardType))
			{
				iform.setStyle("CUSTOMER_NAME", "disable", "false");
				iform.setStyle("EXPIRY_DATE", "disable", "false");
				iform.setStyle("MOBILE_NO", "disable", "false");
				iform.setStyle("EMAIL_ID", "disable", "false");
				iform.setStyle("GENERAL_STATUS", "disable", "false");
				iform.setStyle("ELITE_CUST_NO", "disable", "false");
				iform.setStyle("CARD_CRN_NO", "disable", "false");
				iform.setStyle("CIF_ID", "disable", "false");
				iform.setStyle("CUSTOMER_NAME", "mandatory", "true");
				iform.setStyle("MOBILE_NO", "mandatory", "true");
				iform.setStyle("EMAIL_ID", "mandatory", "true");
				iform.setStyle("CustomerSearch", "disable", "true");
			}
			else
			{
				iform.setStyle("CUSTOMER_NAME", "mandatory", "false");
				iform.setStyle("MOBILE_NO", "mandatory", "false");
				iform.setStyle("EMAIL_ID", "mandatory", "false");
				iform.setStyle("CUSTOMER_NAME", "disable", "true");
				iform.setStyle("EXPIRY_DATE", "disable", "true");
				iform.setStyle("MOBILE_NO", "disable", "true");
				iform.setStyle("EMAIL_ID", "disable", "true");
				iform.setStyle("GENERAL_STATUS", "disable", "true");
				iform.setStyle("ELITE_CUST_NO", "disable", "true");
				iform.setStyle("CARD_CRN_NO", "disable", "true");
				iform.setStyle("CIF_ID", "disable", "true");
				iform.setStyle("CustomerSearch", "disable", "false");
			}
		}
		else if("MODE_OF_SEARCH".equalsIgnoreCase(controlName))
		{
			clearValue("HEADER_CIF,HEADER_CARD_NO,CARD_TYPE", iform);
			clearValue("CUSTOMER_NAME,EXPIRY_DATE,MOBILE_NO,EMAIL_ID,GENERAL_STATUS,ELITE_CUST_NO,CARD_CRN_NO,CIF_ID",iform);
			if("Card".equalsIgnoreCase((String) iform.getValue("MODE_OF_SEARCH")))
			{
				iform.setStyle("HEADER_CIF", "visible", "false");
				iform.setStyle("HEADER_CARD_NO", "visible", "true");
				iform.setStyle("CARD_TYPE", "visible", "true");
			}
			else
			{
				iform.setStyle("HEADER_CIF", "visible", "true");
				iform.setStyle("HEADER_CARD_NO", "visible", "false");
				iform.setStyle("CARD_TYPE", "visible", "false");

				iform.setStyle("CUSTOMER_NAME", "mandatory", "false");
				iform.setStyle("MOBILE_NO", "mandatory", "false");
				iform.setStyle("EMAIL_ID", "mandatory", "false");
				iform.setStyle("CUSTOMER_NAME", "disable", "true");
				iform.setStyle("EXPIRY_DATE", "disable", "true");
				iform.setStyle("MOBILE_NO", "disable", "true");
				iform.setStyle("EMAIL_ID", "disable", "true");
				iform.setStyle("GENERAL_STATUS", "disable", "true");
				iform.setStyle("ELITE_CUST_NO", "disable", "true");
				iform.setStyle("CARD_CRN_NO", "disable", "true");
				iform.setStyle("CIF_ID", "disable", "true");
				iform.setStyle("CustomerSearch", "disable", "false");
			}
			
		}
		//Manthan 
				
		else if("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS_CATEGORY".equalsIgnoreCase(controlName) && "Card_Dispute_Maker".equalsIgnoreCase(Workstep)){
			
			String category=(String) iform.getValue("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS_CATEGORY");
			if("Secured".equalsIgnoreCase(category)){
				iform.setStyle("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS_TYPES_SRCURED_TRANS", "mandatory", "true");
			}
			else{
				iform.setStyle("Q_NG_TS_TRANS_DISPUTE_GRID_DTLS_TYPES_SRCURED_TRANS", "mandatory", "false");
			}
		}
		
		return strReturn;
	}
	
	
	
}
