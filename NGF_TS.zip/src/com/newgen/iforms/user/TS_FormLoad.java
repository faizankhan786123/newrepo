package com.newgen.iforms.user;

import org.json.simple.JSONArray;
import java.util.List;
import java.util.Properties;

import org.json.simple.JSONObject;
import com.newgen.iforms.custom.IFormReference;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class TS_FormLoad extends TS_Common
{
	
	public String formLoadEvent(IFormReference iform, String controlName,String event, String data)
	{
		String strReturn=""; 
	
		TS.mLogger.debug("This is TS_FormLoad_Event"+event+" controlName :"+controlName);
		
		String Workstep=iform.getActivityName();
		String ServiceType = (String) iform.getValue("SERVICE_TYPE");
		TS.mLogger.debug("WINAME : "+getWorkitemName(iform)+", WSNAME: "+iform.getActivityName()+", Workstep :"+Workstep);
		
		
		
		/*********************Loading Deciion**************************/
		try
		{
			if("Initiation".equalsIgnoreCase(Workstep))
			{
				ServiceType="Initiation";
				iform.setStyle("DecisionTab","visible","false");
				
			}
			else
			{
				List lstDecisions = iform.getDataFromDB("SELECT distinct (DECISION) FROM NG_TS_DECISION_MASTER WITH(NOLOCK) WHERE WORKSTEP_NAME='"+Workstep+"' and SERVICE_NAME='"+ServiceType+"' and ISACTIVE='Y' ORDER BY DECISION ASC");
				String value="";
				iform.clearCombo("Decision");
				for(int i=0;i<lstDecisions.size();i++)
				{
					List<String> arr1=(List)lstDecisions.get(i);
					value=arr1.get(0);
					iform.addItemInCombo("Decision",value,value);
					strReturn="Decision Loaded";
				}	
			}
		} 
		catch (Exception e) 
		{
			TS.mLogger.debug("WINAME : "+getWorkitemName(iform)+", WSNAME: "+Workstep+", Exception in Decision drop down load " + e.getMessage());
		}
		
		try
		{
			List lstDecisions = iform.getDataFromDB("select REJECT_REASON from NG_TS_REJECT_REASON_MASTER with(nolock) where SERVICE_NAME='"+ServiceType+"' and ISACTIVE='Y'");
			String Rejvalue="";
			iform.clearCombo("REJECT_REASON");
			for(int i=0;i<lstDecisions.size();i++)
			{
				List<String> arr1=(List)lstDecisions.get(i);
				Rejvalue=arr1.get(0);
				iform.addItemInCombo("REJECT_REASON",Rejvalue,Rejvalue);
			}	
			
		} 
		catch (Exception e) 
		{
			TS.mLogger.debug("WINAME : "+getWorkitemName(iform)+", WSNAME: "+Workstep+", Exception in REJECT_REASON drop down load " + e.getMessage());
		}
		
		/*****************************************************************/
		
		/**********************Enable Disable Control***************************/
	
		TS.mLogger.debug("Inside Enable Disable Control " );
		ServiceType = (String) iform.getValue("SERVICE_TYPE");
		if (Workstep.equalsIgnoreCase("Initiation") && ("".equalsIgnoreCase(ServiceType)  || ServiceType==null)) 
		{
			TS.mLogger.debug("Inside WI_Name " +Workstep); 
			iform.setStyle("creditShieldCancellation","visible","false");
			iform.setStyle("creditShieldInsuranceClaim","visible","false");
			iform.setStyle("RAKProtect","visible","false");
			iform.setStyle("cardDispute","visible","false");
			iform.setStyle("ATMDispute","visible","false");
			iform.setStyle("VERIFICATION_DTLS","disable","false"); 
		}
		else if (!(Workstep.equalsIgnoreCase("Initiation"))) 
		{
			TS.mLogger.debug("Inside WI_Name " +Workstep); 
			iform.setStyle("HEADER_SECTION","disable","true");
			if(Workstep.equalsIgnoreCase("Tele_Sales_Maker") || Workstep.equalsIgnoreCase("Card_Products")
			|| Workstep.equalsIgnoreCase("Card_Settlement_Maker")|| Workstep.equalsIgnoreCase("Card_Maintenance_Maker") 
			|| Workstep.equalsIgnoreCase("Collections") || Workstep.equalsIgnoreCase("COPS") || Workstep.equalsIgnoreCase("Bancassurance")
			|| Workstep.equalsIgnoreCase("Branch_Initiation"))
			{
				if(Workstep.equalsIgnoreCase("Tele_Sales_Maker"))
				{
					iform.setStyle("CSC_NON_CONTACTABLE_BTN","visible","true");
				}
				if(Workstep.equalsIgnoreCase("Bancassurance"))
				{
					iform.setStyle("RP_NON_CONTACTABLE_BTN","visible","true");
				}
				enableTSControl(Workstep,"", iform);
				applyMandatory(iform,Workstep,ServiceType);
			}
		}
		if((Workstep.equalsIgnoreCase("Initiation") || (Workstep.equalsIgnoreCase("Branch_Return"))) && !("".equalsIgnoreCase(ServiceType) && ServiceType==null))
		{
//			cardTypeValidation(iform);
//			userTypeValidation(iform);
			enableTSControl("",ServiceType, iform);
			String CardType=(String) iform.getValue("CARD_TYPE");
			new TS_Integration().isSRORaised(iform);
			if("Prepaid Card".equalsIgnoreCase(CardType))
			{
				iform.setStyle("CUSTOMER_NAME", "disable", "false");
				iform.setStyle("EXPIRY_DATE", "disable", "false");
				iform.setStyle("MOBILE_NO", "disable", "false");
				iform.setStyle("EMAIL_ID", "disable", "false");
				iform.setStyle("GENERAL_STATUS", "disable", "false");
				iform.setStyle("ELITE_CUST_NO", "disable", "false");
				iform.setStyle("CARD_CRN_NO", "disable", "false");
				iform.setStyle("CIF_ID", "disable", "false");
				iform.setStyle("CUSTOMER_NAME", "mandatory", "true");
				iform.setStyle("MOBILE_NO", "mandatory", "true");
				iform.setStyle("EMAIL_ID", "mandatory", "true");
				iform.setStyle("CustomerSearch", "disable", "true");
			}
			iform.setStyle("CUSTOMER_TYPE","disable","false");
			iform.setStyle("SOURCE_ID","disable","false");
			iform.setStyle("EXT_NO","disable","false");
			iform.setStyle("VERIFICATION_DTLS","disable","false"); 
		}
		ServiceVisibility(iform, ServiceType);
		
		/****************************************************/
		
		/*********************ApplyMandatory******************************/
		
		applyMandatory(iform,Workstep,ServiceType);
		
		/****************************************************/
		
		strReturn="Done";
		
		return strReturn;
	}
	
	
	
}
